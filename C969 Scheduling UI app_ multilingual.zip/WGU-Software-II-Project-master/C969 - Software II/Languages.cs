﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchedulingAssistant
{
    public class Languages
    {
        public string save;
        public string signOn;
        public string userName;
        public string password;
        public string logOnError;
        public string close;
        public string overlapError;
        public string startTime;
        public string endTime;
        public string customer;
        public string consultant;
        public string title;
        public string location;
        public string type;
        public string contact;
        public string description;
        public string cancel;
        public string addUpdateAppointmentsForm;
        public string day;
        public string week;
        public string month;
        public string addAppointment;
        public string updateAppointment;
        public string exit;
        public string customers;
        public string appointments;
        public string schedulingAssistant;
        public string add;
        public string delete;
        public string update;
        public string active;
        public string customerName;
        public string phone;
        public string address;
        public string city;
        public string postalCode;
        public string country;
        public string addUpdateCustomers;
        public string logOnLog;
        public string start;
        public string end;
        public string afterHours;
        public string startGreaterThanEnd;
        public string customerAlreadyExists;
        public string alert;

        public void English()
        {
            save = "Save";
            signOn = "Sign On";
            userName = "Username";
            password = "Password";
            logOnError = "The username and password did not match.";
            close = "Close";
            overlapError = "New appointment overlaps with ";
            startTime = "Start Time";
            endTime = "End Time";
            customer = "Customer";
            consultant = "Consultant";
            title = "Title";
            location = "Location";
            type = "Type";
            contact = "Contact";
            description = "Description";
            cancel = "Cancel";
            addUpdateAppointmentsForm = "Add/Update Appointments";
            day = "Day";
            week = "Week";
            month = "Month";
            addAppointment = "Add Appointment";
            updateAppointment = "Update Appointment";
            exit = "Exit";
            customers = "Customers";
            appointments = "Appointments";
            schedulingAssistant = "Scheduling Assistant";
            add = "Add";
            delete = "Delete";
            update = "Update";
            active = "Active";
            customerName = "Customer Name";
            phone = "Phone";
            address = "Address";
            city = "City";
            postalCode = " Postal Code";
            country = "Country";
            addUpdateCustomers = "Add/Update Customers";
            logOnLog = " logged in";
            start = "Start";
            end = "End";
            afterHours = "Meeting time would fall outside working hours (8am-5pm).";
            startGreaterThanEnd = "Start time can not be after end time.";
            customerAlreadyExists = "already exists.";
            alert = "is starting soon.";
        }

        public void Spanish()
        {
            save = "Salvar";
            signOn = "Inscribirse";
            userName = "Nombre de Usuario";
            password = "Contraseña";
            logOnError = "El nombre de usuario y la contraseña no coinciden.";
            close = "Cerca";
            overlapError = "La nueva cita se superpone con ";
            startTime = "Hora de Inicio";
            endTime = "Hora de Finalización";
            customer = "Cliente";
            consultant = "Consultor";
            title = "Título";
            location = "Ubicación";
            type = "Tipo";
            contact = "Contacto";
            description = "Descripción";
            cancel = "Cancelar";
            addUpdateAppointmentsForm = "Agregar/Actualizar Citas";
            day = "Día";
            week = "Semana";
            month = "Mes";
            addAppointment = "Añadir Cita";
            updateAppointment = "Actualizar Cita";
            exit = "Salida";
            customers = "Clientes";
            appointments = "Cita";
            schedulingAssistant = "Asistente de Programación";
            add = "Añadir";
            delete = "Eliminar";
            update = "Actualizar";
            active = "Activo";
            customerName = "Nombre del Cliente";
            phone = "Teléfono";
            address = "El Domicilio";
            city = "La Ciudad";
            postalCode = "Código Postal";
            country = "El País";
            addUpdateCustomers = "Agregar/Actualizar Clientes";
            logOnLog = " registrado en";
            start = "Comienzo";
            end = "Final";
            afterHours = "El tiempo de reunión caería fuera del horario laboral (8am-5pm).";
            startGreaterThanEnd = "La hora de inicio no puede ser posterior a la hora de finalización.";
            customerAlreadyExists = "ya existe.";
            alert = "está comenzando pronto.";
        }
    }
}
