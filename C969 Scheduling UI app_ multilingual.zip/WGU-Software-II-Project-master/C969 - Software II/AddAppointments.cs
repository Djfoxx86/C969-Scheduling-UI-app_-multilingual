﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace SchedulingAssistant
{
    public partial class AddAppointments : Form
    {
        public Appointments appointments;
        private DbRepository repo = new DbRepository();
        private Languages _languages;
        private TimeSpan beginningBusiness;
        private TimeSpan endBusiness;
        private bool update = false;
        private Appointment _appoingmentToUpdate;

        public AddAppointments(Appointments appointmentsMain, Languages language)
        {
            beginningBusiness = new TimeSpan(8, 0, 0);
            endBusiness = new TimeSpan(17, 0, 0);
            _languages = language;
            appointments = appointmentsMain;
            InitializeComponent();
            customerDropDown.DataSource = repo.GetAllCustomers();
            consultantDropDown.DataSource = repo.GetAllUsers();
            startDateTimePicker.Format = DateTimePickerFormat.Custom;
            startDateTimePicker.CustomFormat = "MM/dd/yyyy hh:mm tt";
            endDateTimePicker.Format = DateTimePickerFormat.Custom;
            endDateTimePicker.CustomFormat = "MM/dd/yyyy hh:mm tt";
            SetLanguage();
            QualityCheck();
        }

        public AddAppointments(Appointments appointmentsMain, Languages language, DateTime startTime, DateTime endTime,
            string customerName, string user, string title, string location, string type, string url, string contact,
            string description)
        {
            _appoingmentToUpdate = repo.GetAppointmentToUpdate(startTime, endTime, title);
            beginningBusiness = new TimeSpan(8, 0, 0);
            endBusiness = new TimeSpan(17, 0, 0);
            _languages = language;
            appointments = appointmentsMain;
            InitializeComponent();
            customerDropDown.DataSource = repo.GetAllCustomers();
            consultantDropDown.DataSource = repo.GetAllUsers();
            startDateTimePicker.Format = DateTimePickerFormat.Custom;
            startDateTimePicker.CustomFormat = "MM/dd/yyyy hh:mm tt";
            endDateTimePicker.Format = DateTimePickerFormat.Custom;
            endDateTimePicker.CustomFormat = "MM/dd/yyyy hh:mm tt";
            startDateTimePicker.Value = startTime.ToLocalTime();
            endDateTimePicker.Value = endTime.ToLocalTime();
            customerDropDown.SelectedIndex = customerDropDown.FindStringExact(customerName);
            consultantDropDown.SelectedIndex = consultantDropDown.FindStringExact(user);
            titleText.Text = title;
            locationText.Text = location;
            typeText.Text = type;
            urlText.Text = url;
            contactText.Text = contact;
            descriptionText.Text = description;
            update = true;
            SetLanguage();
            QualityCheck();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if(startDateTimePicker.Value.TimeOfDay < beginningBusiness || startDateTimePicker.Value.TimeOfDay > endBusiness || endDateTimePicker.Value.TimeOfDay > endBusiness)
            {
                AfterWorkHours ex = new AfterWorkHours(_languages.afterHours);
                ExceptionMessage message = new ExceptionMessage(ex.Message, _languages);
                message.Show();
            }
            else if(startDateTimePicker.Value > endDateTimePicker.Value)
            {
                StartGreaterThanEnd ex = new StartGreaterThanEnd(_languages.startGreaterThanEnd);
                ExceptionMessage message = new ExceptionMessage(ex.Message, _languages);
                message.Show();
            }
            else
            {
                try
                {
                    AddAppointment();
                    appointments.Refresh();
                    this.Close();
                }
                catch (OverflowException ex)
                {
                    ExceptionMessage message = new ExceptionMessage(ex.Message, _languages);
                    message.Show();
                }
            }
        }

        private bool CheckOverlap(List<Appointment> appointments, DateTime startTime, DateTime endTime)
        {
            //use lamda to iterate over appointments for the day to populate an IEnumerable if the new appointment start time is during an existing appointment
            IEnumerable<Appointment> checkStart = appointments.Where(x => x.startTime < startTime)
                .Where(apt => apt.endTime > startTime);

            //use lamda to iterate over appointments for the day to populate an IEnumerable if the new appointment end time is during an existing appointment
            IEnumerable<Appointment> checkEnd = appointments.Where(x => x.startTime > startTime)
                .Where(apt => apt.startTime < endTime);

            //use lamda to iterate over appointments for the day to populate an IEnumerable if the new appointment encompasses an existing appointment
            IEnumerable<Appointment> checkEncompassed = appointments.Where(apt => apt.startTime < startTime)
                .Where(x => x.endTime > endTime);
            if (checkStart.Any())
            {
                throw new OverflowException(String.Format("{1} {0}",checkStart.FirstOrDefault().title, _languages.overlapError));
            }
            else if (checkEnd.Any())
            {
                throw  new OverflowException(String.Format("{1} {0}",checkEnd.FirstOrDefault().title, _languages.overlapError));
            }
            else if (checkEncompassed.Any())
            {
                throw new OverflowException(String.Format("{1} {0}", checkEnd.FirstOrDefault().title, _languages.overlapError));
            }
            else
            {
                return false;
            }
        }

        private void startDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime tempStart = startDateTimePicker.Value;
            DateTime tempEnd = endDateTimePicker.Value;
            if (tempStart.ToString("d") != tempEnd.ToString("d"))
            {
                endDateTimePicker.Value = DateTime.Parse(tempStart.ToString("d") + " " + tempEnd.ToString("t"));
            }
        }

        private void endDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime tempStart = startDateTimePicker.Value;
            DateTime tempEnd = endDateTimePicker.Value;
            if (tempStart.ToString("d") != tempEnd.ToString("d"))
            {
                startDateTimePicker.Value = DateTime.Parse(tempEnd.ToString("d") + " " + tempStart.ToString("t"));
            }
        }

        private void AddAppointment()
        {
            DateTime start = DateTime.Parse(startDateTimePicker.Value.ToString("MM/dd/yyyy HH:mm:00")).ToUniversalTime();
            DateTime end = DateTime.Parse(endDateTimePicker.Value.ToString("MM/dd/yyyy HH:mm:59")).ToUniversalTime();
            DateTime checkStartDate = DateTime.Parse(start.ToString("MM/dd/yyyy 00:00:00"));
            DateTime checkEndDate = checkStartDate.AddDays(1);
            List <Appointment> check = repo.GetAppointmentsList(checkStartDate, checkEndDate);
            if (check.Any())
            {
                if (!CheckOverlap(check, startDateTimePicker.Value, endDateTimePicker.Value))
                {
                    if (update)
                    {
                        repo.UpdateAppointment(customerDropDown.SelectedValue.ToString(), consultantDropDown.SelectedValue.ToString(), titleText.Text, descriptionText.Text,
                            locationText.Text, contactText.Text, typeText.Text, urlText.Text, start, end, appointments.landing.currentUser, _appoingmentToUpdate.appointmentId);
                    }
                    else
                    {
                        repo.AddAppointment(customerDropDown.SelectedValue.ToString(), consultantDropDown.SelectedValue.ToString(), titleText.Text, descriptionText.Text,
                            locationText.Text, contactText.Text, typeText.Text, urlText.Text, start, end, appointments.landing.currentUser);
                    }
                }
            }
            else
            {
                if (update)
                {
                    repo.UpdateAppointment(customerDropDown.SelectedValue.ToString(), consultantDropDown.SelectedValue.ToString(), titleText.Text, descriptionText.Text,
                        locationText.Text, contactText.Text, typeText.Text, urlText.Text, start, end, appointments.landing.currentUser, _appoingmentToUpdate.appointmentId);
                }
                else
                {
                    repo.AddAppointment(customerDropDown.SelectedValue.ToString(), consultantDropDown.SelectedValue.ToString(), titleText.Text, descriptionText.Text,
                        locationText.Text, contactText.Text, typeText.Text, urlText.Text, start, end, appointments.landing.currentUser);
                }
            }
        }

        public void SetLanguage()
        {
            startTimeLabel.Text = _languages.startTime;
            endTimeLabel.Text = _languages.endTime;
            customerLabel.Text = _languages.customer;
            consultantLabel.Text = _languages.consultant;
            titleLabel.Text = _languages.title;
            locationLabel.Text = _languages.location;
            typeLabel.Text = _languages.type;
            contactLabel.Text = _languages.contact;
            descriptionLabel.Text = _languages.description;
            saveButton.Text = _languages.save;
            cancelButton.Text = _languages.cancel;
            this.Text = _languages.addUpdateAppointmentsForm;
        }
        private void QualityCheck()
        {
            if (titleText.BackColor == System.Drawing.Color.Yellow ||
                locationText.BackColor == System.Drawing.Color.Yellow ||
                typeText.BackColor == System.Drawing.Color.Yellow ||
                urlText.BackColor == System.Drawing.Color.Yellow ||
                contactText.BackColor == System.Drawing.Color.Yellow ||
                descriptionText.BackColor == System.Drawing.Color.Yellow)
            {
                saveButton.Enabled = false;
            }
            else
            {
                saveButton.Enabled = true;
            }
        }

        private void TitleText_TextChanged(object sender, EventArgs e)
        {
            titleText.BackColor = titleText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void LocationText_TextChanged(object sender, EventArgs e)
        {
            locationText.BackColor = locationText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void TypeText_TextChanged(object sender, EventArgs e)
        {
            typeText.BackColor = typeText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void UrlText_TextChanged(object sender, EventArgs e)
        {
            urlText.BackColor = Regex.IsMatch(urlText.Text, "http://") && urlText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void ContactText_TextChanged(object sender, EventArgs e)
        {
            contactText.BackColor = contactText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void DescriptionText_TextChanged(object sender, EventArgs e)
        {
            descriptionText.BackColor = descriptionText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }
    }

    [Serializable]
    class OverlapException : Exception
    {
        public OverlapException()
        {

        }

        public OverlapException(string message) 
            : base (message)
        {

        }
    }

    [Serializable]
    class AfterWorkHours : Exception
    {
        public AfterWorkHours()
        {

        }

        public AfterWorkHours(string message)
            : base(message)
        {

        }
    }

    [Serializable]
    class StartGreaterThanEnd : Exception
    {
        public StartGreaterThanEnd()
        {

        }

        public StartGreaterThanEnd(string message)
            : base(message)
        {

        }
    }
}
