﻿using System;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace SchedulingAssistant
{
    public partial class Login : Form
    {
        public string currentUser;
        DbRepository repo = new DbRepository();
        private Languages _language;
        public Login()
        {
            _language = SetMainLanguage();
            InitializeComponent();
            SetLanguage();
        }

        private void signOn_Click(object sender, EventArgs e)
        {
            string loginResults = repo.SignOn(usernameTextBox.Text, passwordTextBox.Text);
            if (loginResults == "True")
            {
                currentUser = usernameTextBox.Text;
                DateTime time = DateTime.UtcNow;
                WriteToLog(currentUser, time);
                this.Hide();
                Appointments appointmentsForm = new Appointments(this, _language);
                appointmentsForm.Closed += (s, args) => this.Close();
                appointmentsForm.Show();
            }
            else
            {
                ExceptionMessage message = new ExceptionMessage(_language.logOnError, _language);
                message.Show();
            }
        }

        private void WriteToLog(string user, DateTime time)
        {
            string path = System.IO.Path.GetFullPath(@"..\..\logs");
            path += @"\log.txt";
            if (!File.Exists(path))
            {
                using (StreamWriter sw = File.CreateText(path))
                {
                    sw.WriteLine("{0} {1} {2}", time, user, _language.logOnLog);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(path))
                {
                    sw.WriteLine("{0} {1} {2}", time, user, _language.logOnLog);
                }
            }
        }

        public Languages SetMainLanguage()
        {
            CultureInfo ci = CultureInfo.CurrentCulture;
            Languages lang = new Languages();
            switch (ci.Name)
            {
                case "en-US":
                    lang.English();
                    break;
                case "es-ES":
                    lang.Spanish();
                    break;
                default:
                    lang.English();
                    break;
            }

            return lang;
        }

        public void SetLanguage()
        {
            usernameLabel.Text = _language.userName;
            passwordLabel.Text = _language.password;
            signOn.Text = _language.signOn;
            this.Text = _language.schedulingAssistant;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }


    [Serializable]
    public class LoginInException : Exception
    {
        public LoginInException()
        {

        }

        public LoginInException(string message)
            : base(message)
        {

        }

    }
}
