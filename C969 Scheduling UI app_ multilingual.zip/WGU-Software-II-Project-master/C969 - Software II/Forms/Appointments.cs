﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;


namespace C969__Software_II
{
    public partial class Appointments : Form
    {
        public Login landing;
        private DbHelper repo = new DbHelper();
        private DateTime startDate;
        private DateTime endDate;
        private DataTable dt;
        private List<Appointment> dailyApts;
        private List<Appointment> alertedApts;
        public Appointments(Login landingMain)
        {
            alertedApts = new List<Appointment>();
            landing = landingMain;
            InitializeComponent();
            startDate = DateTime.Today;
            endDate = DateTime.Today.AddDays(1);
            dgvAppointments.RowHeadersVisible = false;
            dgvAppointments.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            UpdateAppointmentGrid(startDate.ToUniversalTime(), endDate.ToUniversalTime());
            dgvAppointments.DataSource = dt;
            dailyApts = GetTodaysAppointments();
        }

        private void customer_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customers customers = new Customers(this);
            customers.Closed += (s, args) => this.Show();
            customers.Show();
        }

        private void MonthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            startDate = e.Start;
            if (radioDay.Checked)
            {
                HandleDay();
            }

            if (radioWeek.Checked)
            {
                HandleWeek();
            }

            if (radioMonth.Checked)
            {
                HandleMonth();
            }
        }

        private void HandleDay()
        {
            endDate = startDate.AddDays(1);
            cal.RemoveAllBoldedDates();
            cal.AddBoldedDate(startDate);
            cal.UpdateBoldedDates();
            UpdateAppointmentGrid(startDate.ToUniversalTime(), endDate.ToUniversalTime());
            this.Refresh();
        }

        private void HandleWeek()
        {
            int dow = (int)startDate.DayOfWeek;
            startDate = startDate.AddDays(-dow);
            endDate = startDate.AddDays(7);
            cal.RemoveAllBoldedDates();
            for (int i = 0; i < 7; i++)
            {
                cal.AddBoldedDate(startDate.AddDays(i));
            }
            cal.UpdateBoldedDates();
            UpdateAppointmentGrid(startDate.ToUniversalTime(), endDate.ToUniversalTime());
            this.Refresh();
        }

        private void HandleMonth()
        {
            startDate = new DateTime(startDate.Year, startDate.Month, 1);
            endDate = startDate.AddMonths(1).AddDays(-1);
            int numberOfDays = DateTime.DaysInMonth(startDate.Year, startDate.Month);
            cal.RemoveAllBoldedDates();
            for (int i = 0; i < numberOfDays; i++)
            {
                cal.AddBoldedDate(startDate.AddDays(i));
            }
            cal.UpdateBoldedDates();
            UpdateAppointmentGrid(startDate.ToUniversalTime(), endDate.ToUniversalTime());
            this.Refresh();
        }

        public void UpdateAppointmentGrid(DateTime startDate, DateTime endDate)
        {
            List<Appointment> apts = new List<Appointment>();
            apts = repo.GetAppointmentsList(startDate, endDate);
            DataTable formattedApts = new DataTable();
            formattedApts.Columns.Add("start", typeof(DateTime));
            formattedApts.Columns.Add("end", typeof(DateTime));
            formattedApts.Columns.Add("customer", typeof(string));
            formattedApts.Columns.Add("consultant", typeof(string));
            formattedApts.Columns.Add("title", typeof(string));
            formattedApts.Columns.Add("type", typeof(string));
            formattedApts.Columns.Add("contact", typeof(string));
            formattedApts.Columns.Add("location", typeof(string));
            formattedApts.Columns.Add("URL", typeof(string));
            formattedApts.Columns.Add("description", typeof(string));
            for(int i = 0; i <= apts.Count - 1; i++)
            {
                DataRow row = formattedApts.NewRow();
                row["start"] = apts[i].startTime;
                row["end"] = apts[i].endTime;
                row["customer"] = apts[i].customerName;
                row["consultant"] = apts[i].user;
                row["title"] = apts[i].title;
                row["type"] = apts[i].aptType;
                row["contact"] = apts[i].contact;
                row["location"] = apts[i].location;
                row["URL"] = apts[i].url;
                row["description"] = apts[i].description;
                formattedApts.Rows.Add(row);
            }
            dt = formattedApts;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addAppointment_Click(object sender, EventArgs e)
        {
            AddAppointments addAppointments = new AddAppointments(this);
            addAppointments.Show();
        }

        public override void Refresh()
        {
            UpdateAppointmentGrid(startDate.ToUniversalTime(), endDate.ToUniversalTime());
            dgvAppointments.DataSource = dt;
            UpdateAlertLists();
            base.Refresh();
        }

        private void radioWeek_CheckedChanged(object sender, EventArgs e)
        {
            HandleWeek();
        }

        private void radioMonth_CheckedChanged(object sender, EventArgs e)
        {
            HandleMonth();
        }

        private void radioDay_CheckedChanged(object sender, EventArgs e)
        {
            HandleDay();
        }

        private void updateAppointment_Click(object sender, EventArgs e)
        {
            Appointment apt = repo.GetAppointmentToUpdate(
                DateTime.Parse(dgvAppointments.SelectedCells[0].Value.ToString()).ToUniversalTime(),
                DateTime.Parse(dgvAppointments.SelectedCells[1].Value.ToString()).ToUniversalTime(),
                dgvAppointments.SelectedCells[4].Value.ToString());
            AddAppointments addAppointments = new AddAppointments(this, apt.startTime, apt.endTime, apt.customerName, apt.user, apt.title, apt.location, apt.aptType, apt.url, apt.contact, apt.description);
            addAppointments.Show();
        }

        private List<Appointment> CheckAppointments()
        {
            UpdateAlertLists();
            List<Appointment> temp = new List<Appointment>();
            
            
            foreach (var apt in dailyApts)
            {
                if (apt.startTime < DateTime.Now.AddMinutes(15) && apt.startTime >= DateTime.Now)
                {
                    temp.Add(apt);
                }
            }
            return temp;
        }

        private void Alert()
        {
            var apts = CheckAppointments();
            if (apts.Count > 0)
            {
                foreach (var apt in apts)
                {
                    string message = String.Format("Upcoming Appointments:" + Environment.NewLine + Environment.NewLine + "{0} @ {1}", apt.customerName, apt.startTime);
                    AlertMessage alert = new AlertMessage(message);
                    alertedApts.Add(apt);
                    dailyApts.Remove(apt);
                    alert.Activate();
                    alert.Show();
                    alert.TopMost = true;

                }
            }
        }


        private void UpdateAlertLists()
        {
            //Use lambda expression to find upcoming appointments
            List<Appointment> temp = GetTodaysAppointments();
            List<Appointment> results = new List<Appointment>();
            if (alertedApts.Count > 0)
            {
                results = temp.Where(x => !alertedApts.Any(y => y == x)).ToList();
            }
            else
            {
                results = temp;
            }
            dailyApts = results;
        }

        private List<Appointment> GetTodaysAppointments()
        {
            var results = repo.GetAppointmentsList(DateTime.Today.ToUniversalTime(), DateTime.Today.AddDays(1).ToUniversalTime());
            return results;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Alert();
        }

        private void Appointments_Load(object sender, EventArgs e)
        {
            Alert();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            repo.DeleteAppointment(
                DateTime.Parse(dgvAppointments.SelectedCells[0].Value.ToString()).ToUniversalTime(),
                DateTime.Parse(dgvAppointments.SelectedCells[1].Value.ToString()).ToUniversalTime(),
                dgvAppointments.SelectedCells[4].Value.ToString());
            this.Refresh();
        }

        private void numbApt_Click(object sender, EventArgs e)
        {
            GenerateReport gr = new GenerateReport(1);
            gr.Show();
        }

        private void conSched_Click(object sender, EventArgs e)
        {
            GenerateReport gr = new GenerateReport(2);
            gr.Show();
        }

        private void custScedReport_Click(object sender, EventArgs e)
        {
            GenerateReport gr = new GenerateReport(3);
            gr.Show();
        }
    }
}
