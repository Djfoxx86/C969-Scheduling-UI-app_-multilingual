﻿namespace C969__Software_II
{
    partial class Appointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.customers = new System.Windows.Forms.Button();
            this.dgvAppointments = new System.Windows.Forms.DataGridView();
            this.addAppointment = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.cal = new System.Windows.Forms.MonthCalendar();
            this.radioDay = new System.Windows.Forms.RadioButton();
            this.radioWeek = new System.Windows.Forms.RadioButton();
            this.radioMonth = new System.Windows.Forms.RadioButton();
            this.radioPanel = new System.Windows.Forms.Panel();
            this.updateAppointment = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.delete = new System.Windows.Forms.Button();
            this.numbApt = new System.Windows.Forms.Button();
            this.conSched = new System.Windows.Forms.Button();
            this.custScedReport = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppointments)).BeginInit();
            this.radioPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // customers
            // 
            this.customers.Location = new System.Drawing.Point(12, 437);
            this.customers.Name = "customers";
            this.customers.Size = new System.Drawing.Size(81, 25);
            this.customers.TabIndex = 4;
            this.customers.Text = "Customer List";
            this.customers.UseVisualStyleBackColor = true;
            this.customers.Click += new System.EventHandler(this.customer_Click);
            // 
            // dgvAppointments
            // 
            this.dgvAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAppointments.Location = new System.Drawing.Point(287, 255);
            this.dgvAppointments.Name = "dgvAppointments";
            this.dgvAppointments.Size = new System.Drawing.Size(666, 293);
            this.dgvAppointments.TabIndex = 5;
            // 
            // addAppointment
            // 
            this.addAppointment.Location = new System.Drawing.Point(491, 568);
            this.addAppointment.Name = "addAppointment";
            this.addAppointment.Size = new System.Drawing.Size(75, 23);
            this.addAppointment.TabIndex = 6;
            this.addAppointment.Text = "Add";
            this.addAppointment.UseVisualStyleBackColor = true;
            this.addAppointment.Click += new System.EventHandler(this.addAppointment_Click);
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(869, 664);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(84, 33);
            this.exit.TabIndex = 7;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // cal
            // 
            this.cal.Location = new System.Drawing.Point(705, 81);
            this.cal.Name = "cal";
            this.cal.TabIndex = 8;
            this.cal.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.MonthCalendar1_DateChanged);
            // 
            // radioDay
            // 
            this.radioDay.AutoSize = true;
            this.radioDay.Checked = true;
            this.radioDay.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioDay.Location = new System.Drawing.Point(15, 13);
            this.radioDay.Name = "radioDay";
            this.radioDay.Size = new System.Drawing.Size(45, 18);
            this.radioDay.TabIndex = 9;
            this.radioDay.TabStop = true;
            this.radioDay.Text = "Day";
            this.radioDay.UseVisualStyleBackColor = true;
            this.radioDay.CheckedChanged += new System.EventHandler(this.radioDay_CheckedChanged);
            // 
            // radioWeek
            // 
            this.radioWeek.AutoSize = true;
            this.radioWeek.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioWeek.Location = new System.Drawing.Point(76, 13);
            this.radioWeek.Name = "radioWeek";
            this.radioWeek.Size = new System.Drawing.Size(57, 18);
            this.radioWeek.TabIndex = 11;
            this.radioWeek.Text = "Week";
            this.radioWeek.UseVisualStyleBackColor = true;
            this.radioWeek.CheckedChanged += new System.EventHandler(this.radioWeek_CheckedChanged);
            // 
            // radioMonth
            // 
            this.radioMonth.AutoSize = true;
            this.radioMonth.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioMonth.Location = new System.Drawing.Point(150, 13);
            this.radioMonth.Name = "radioMonth";
            this.radioMonth.Size = new System.Drawing.Size(60, 18);
            this.radioMonth.TabIndex = 10;
            this.radioMonth.Text = "Month";
            this.radioMonth.UseVisualStyleBackColor = true;
            this.radioMonth.CheckedChanged += new System.EventHandler(this.radioMonth_CheckedChanged);
            // 
            // radioPanel
            // 
            this.radioPanel.Controls.Add(this.radioDay);
            this.radioPanel.Controls.Add(this.radioMonth);
            this.radioPanel.Controls.Add(this.radioWeek);
            this.radioPanel.Location = new System.Drawing.Point(705, 25);
            this.radioPanel.Name = "radioPanel";
            this.radioPanel.Size = new System.Drawing.Size(227, 44);
            this.radioPanel.TabIndex = 12;
            // 
            // updateAppointment
            // 
            this.updateAppointment.Location = new System.Drawing.Point(583, 568);
            this.updateAppointment.Name = "updateAppointment";
            this.updateAppointment.Size = new System.Drawing.Size(75, 23);
            this.updateAppointment.TabIndex = 13;
            this.updateAppointment.Text = "Update";
            this.updateAppointment.UseVisualStyleBackColor = true;
            this.updateAppointment.Click += new System.EventHandler(this.updateAppointment_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 60000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(674, 568);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(75, 23);
            this.delete.TabIndex = 14;
            this.delete.Text = "Delete";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // Number of Appointments
            // 
            this.numbApt.Location = new System.Drawing.Point(12, 255);
            this.numbApt.Name = "numbApt";
            this.numbApt.Size = new System.Drawing.Size(174, 28);
            this.numbApt.TabIndex = 15;
            this.numbApt.Text = "Number of Appointments";
            this.numbApt.UseVisualStyleBackColor = true;
            this.numbApt.Click += new System.EventHandler(this.numbApt_Click);
            // 
            // Consultant Schedules
            // 
            this.conSched.Location = new System.Drawing.Point(12, 310);
            this.conSched.Name = "conSched";
            this.conSched.Size = new System.Drawing.Size(174, 28);
            this.conSched.TabIndex = 16;
            this.conSched.Text = "Consultant Schedules";
            this.conSched.UseVisualStyleBackColor = true;
            this.conSched.Click += new System.EventHandler(this.conSched_Click);
            // 
            // Customer Schedule Report
            // 
            this.custScedReport.Location = new System.Drawing.Point(12, 369);
            this.custScedReport.Name = "custScedReport";
            this.custScedReport.Size = new System.Drawing.Size(174, 28);
            this.custScedReport.TabIndex = 18;
            this.custScedReport.Text = "Customer Schedule Report";
            this.custScedReport.UseVisualStyleBackColor = true;
            this.custScedReport.Click += new System.EventHandler(this.custScedReport_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(284, 204);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 18);
            this.label2.TabIndex = 22;
            this.label2.Text = "Appointment Calendar";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Tahoma", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(21, 43);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(189, 39);
            this.titleLabel.TabIndex = 23;
            this.titleLabel.Text = "Dashboard";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(57, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 18);
            this.label3.TabIndex = 25;
            this.label3.Text = "Reports";
            // 
            // Appointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(967, 709);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.custScedReport);
            this.Controls.Add(this.conSched);
            this.Controls.Add(this.numbApt);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.updateAppointment);
            this.Controls.Add(this.radioPanel);
            this.Controls.Add(this.cal);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.addAppointment);
            this.Controls.Add(this.dgvAppointments);
            this.Controls.Add(this.customers);
            this.Name = "Appointments";
            this.Text = "Appointments";
            this.Load += new System.EventHandler(this.Appointments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppointments)).EndInit();
            this.radioPanel.ResumeLayout(false);
            this.radioPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button customers;
        private System.Windows.Forms.DataGridView dgvAppointments;
        private System.Windows.Forms.Button addAppointment;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.MonthCalendar cal;
        private System.Windows.Forms.RadioButton radioDay;
        private System.Windows.Forms.RadioButton radioWeek;
        private System.Windows.Forms.RadioButton radioMonth;
        private System.Windows.Forms.Panel radioPanel;
        private System.Windows.Forms.Button updateAppointment;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button numbApt;
        private System.Windows.Forms.Button conSched;
        private System.Windows.Forms.Button custScedReport;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label label3;
    }
}