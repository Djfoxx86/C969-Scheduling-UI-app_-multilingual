﻿namespace C969__Software_II
{
    partial class AddAppointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.customerLabel = new System.Windows.Forms.Label();
            this.consultantLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.locationLabel = new System.Windows.Forms.Label();
            this.typeLabel = new System.Windows.Forms.Label();
            this.typeText = new System.Windows.Forms.TextBox();
            this.locationText = new System.Windows.Forms.TextBox();
            this.titleText = new System.Windows.Forms.TextBox();
            this.startTimeLabel = new System.Windows.Forms.Label();
            this.startDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.endTimeLabel = new System.Windows.Forms.Label();
            this.endDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.customerDropDown = new System.Windows.Forms.ComboBox();
            this.consultantDropDown = new System.Windows.Forms.ComboBox();
            this.urlLabel = new System.Windows.Forms.Label();
            this.urlText = new System.Windows.Forms.TextBox();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.descriptionText = new System.Windows.Forms.TextBox();
            this.contactLabel = new System.Windows.Forms.Label();
            this.contactText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(386, 528);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(72, 32);
            this.cancelButton.TabIndex = 37;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(308, 528);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(72, 32);
            this.saveButton.TabIndex = 36;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // customerLabel
            // 
            this.customerLabel.AutoSize = true;
            this.customerLabel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerLabel.Location = new System.Drawing.Point(12, 91);
            this.customerLabel.Name = "customerLabel";
            this.customerLabel.Size = new System.Drawing.Size(79, 18);
            this.customerLabel.TabIndex = 33;
            this.customerLabel.Text = "Customer";
            // 
            // consultantLabel
            // 
            this.consultantLabel.AutoSize = true;
            this.consultantLabel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.consultantLabel.Location = new System.Drawing.Point(249, 91);
            this.consultantLabel.Name = "consultantLabel";
            this.consultantLabel.Size = new System.Drawing.Size(88, 18);
            this.consultantLabel.TabIndex = 32;
            this.consultantLabel.Text = "Consultant";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(12, 145);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(42, 18);
            this.titleLabel.TabIndex = 31;
            this.titleLabel.Text = "Title";
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationLabel.Location = new System.Drawing.Point(9, 207);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(72, 18);
            this.locationLabel.TabIndex = 30;
            this.locationLabel.Text = "Location";
            // 
            // typeLabel
            // 
            this.typeLabel.AutoSize = true;
            this.typeLabel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeLabel.Location = new System.Drawing.Point(249, 207);
            this.typeLabel.Name = "typeLabel";
            this.typeLabel.Size = new System.Drawing.Size(44, 18);
            this.typeLabel.TabIndex = 29;
            this.typeLabel.Text = "Type";
            // 
            // typeText
            // 
            this.typeText.BackColor = System.Drawing.Color.Tan;
            this.typeText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeText.Location = new System.Drawing.Point(252, 228);
            this.typeText.Name = "typeText";
            this.typeText.Size = new System.Drawing.Size(200, 26);
            this.typeText.TabIndex = 28;
            this.typeText.TextChanged += new System.EventHandler(this.TypeText_TextChanged);
            // 
            // locationText
            // 
            this.locationText.BackColor = System.Drawing.Color.Tan;
            this.locationText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationText.Location = new System.Drawing.Point(12, 228);
            this.locationText.Name = "locationText";
            this.locationText.Size = new System.Drawing.Size(203, 26);
            this.locationText.TabIndex = 26;
            this.locationText.TextChanged += new System.EventHandler(this.LocationText_TextChanged);
            // 
            // titleText
            // 
            this.titleText.BackColor = System.Drawing.Color.Tan;
            this.titleText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleText.Location = new System.Drawing.Point(12, 166);
            this.titleText.Name = "titleText";
            this.titleText.Size = new System.Drawing.Size(203, 26);
            this.titleText.TabIndex = 25;
            this.titleText.TextChanged += new System.EventHandler(this.TitleText_TextChanged);
            // 
            // startTimeLabel
            // 
            this.startTimeLabel.AutoSize = true;
            this.startTimeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startTimeLabel.Location = new System.Drawing.Point(12, 30);
            this.startTimeLabel.Name = "startTimeLabel";
            this.startTimeLabel.Size = new System.Drawing.Size(86, 18);
            this.startTimeLabel.TabIndex = 23;
            this.startTimeLabel.Text = "Start Time";
            // 
            // startDateTimePicker
            // 
            this.startDateTimePicker.Location = new System.Drawing.Point(15, 51);
            this.startDateTimePicker.Name = "startDateTimePicker";
            this.startDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.startDateTimePicker.TabIndex = 38;
            this.startDateTimePicker.ValueChanged += new System.EventHandler(this.startDateTimePicker_ValueChanged);
            // 
            // endTimeLabel
            // 
            this.endTimeLabel.AutoSize = true;
            this.endTimeLabel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endTimeLabel.Location = new System.Drawing.Point(249, 30);
            this.endTimeLabel.Name = "endTimeLabel";
            this.endTimeLabel.Size = new System.Drawing.Size(75, 18);
            this.endTimeLabel.TabIndex = 34;
            this.endTimeLabel.Text = "End Time";
            // 
            // endDateTimePicker
            // 
            this.endDateTimePicker.Location = new System.Drawing.Point(252, 51);
            this.endDateTimePicker.Name = "endDateTimePicker";
            this.endDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.endDateTimePicker.TabIndex = 39;
            this.endDateTimePicker.ValueChanged += new System.EventHandler(this.endDateTimePicker_ValueChanged);
            // 
            // customerDropDown
            // 
            this.customerDropDown.FormattingEnabled = true;
            this.customerDropDown.Location = new System.Drawing.Point(15, 112);
            this.customerDropDown.Name = "customerDropDown";
            this.customerDropDown.Size = new System.Drawing.Size(200, 21);
            this.customerDropDown.TabIndex = 40;
            // 
            // consultantDropDown
            // 
            this.consultantDropDown.FormattingEnabled = true;
            this.consultantDropDown.Location = new System.Drawing.Point(252, 112);
            this.consultantDropDown.Name = "consultantDropDown";
            this.consultantDropDown.Size = new System.Drawing.Size(200, 21);
            this.consultantDropDown.TabIndex = 41;
            // 
            // urlLabel
            // 
            this.urlLabel.AutoSize = true;
            this.urlLabel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.urlLabel.Location = new System.Drawing.Point(12, 272);
            this.urlLabel.Name = "urlLabel";
            this.urlLabel.Size = new System.Drawing.Size(39, 18);
            this.urlLabel.TabIndex = 43;
            this.urlLabel.Text = "URL";
            // 
            // urlText
            // 
            this.urlText.BackColor = System.Drawing.Color.Tan;
            this.urlText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.urlText.Location = new System.Drawing.Point(15, 293);
            this.urlText.Name = "urlText";
            this.urlText.Size = new System.Drawing.Size(437, 26);
            this.urlText.TabIndex = 42;
            this.urlText.Text = "http://";
            this.urlText.TextChanged += new System.EventHandler(this.UrlText_TextChanged);
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionLabel.Location = new System.Drawing.Point(12, 340);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(94, 18);
            this.descriptionLabel.TabIndex = 45;
            this.descriptionLabel.Text = "Description";
            // 
            // descriptionText
            // 
            this.descriptionText.BackColor = System.Drawing.Color.Tan;
            this.descriptionText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionText.Location = new System.Drawing.Point(15, 361);
            this.descriptionText.Multiline = true;
            this.descriptionText.Name = "descriptionText";
            this.descriptionText.Size = new System.Drawing.Size(437, 116);
            this.descriptionText.TabIndex = 44;
            this.descriptionText.TextChanged += new System.EventHandler(this.DescriptionText_TextChanged);
            // 
            // contactLabel
            // 
            this.contactLabel.AutoSize = true;
            this.contactLabel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactLabel.Location = new System.Drawing.Point(249, 145);
            this.contactLabel.Name = "contactLabel";
            this.contactLabel.Size = new System.Drawing.Size(65, 18);
            this.contactLabel.TabIndex = 47;
            this.contactLabel.Text = "Contact";
            // 
            // contactText
            // 
            this.contactText.BackColor = System.Drawing.Color.Tan;
            this.contactText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactText.Location = new System.Drawing.Point(252, 166);
            this.contactText.Name = "contactText";
            this.contactText.Size = new System.Drawing.Size(200, 26);
            this.contactText.TabIndex = 46;
            this.contactText.TextChanged += new System.EventHandler(this.ContactText_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(55, 276);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 48;
            this.label1.Text = "Format: http://...";
            // 
            // AddAppointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 572);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.contactLabel);
            this.Controls.Add(this.contactText);
            this.Controls.Add(this.descriptionLabel);
            this.Controls.Add(this.descriptionText);
            this.Controls.Add(this.urlLabel);
            this.Controls.Add(this.urlText);
            this.Controls.Add(this.consultantDropDown);
            this.Controls.Add(this.customerDropDown);
            this.Controls.Add(this.endDateTimePicker);
            this.Controls.Add(this.startDateTimePicker);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.endTimeLabel);
            this.Controls.Add(this.customerLabel);
            this.Controls.Add(this.consultantLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.locationLabel);
            this.Controls.Add(this.typeLabel);
            this.Controls.Add(this.typeText);
            this.Controls.Add(this.locationText);
            this.Controls.Add(this.titleText);
            this.Controls.Add(this.startTimeLabel);
            this.Name = "AddAppointments";
            this.Text = "AddAppointments";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Label customerLabel;
        private System.Windows.Forms.Label consultantLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.Label typeLabel;
        private System.Windows.Forms.TextBox typeText;
        private System.Windows.Forms.TextBox locationText;
        private System.Windows.Forms.TextBox titleText;
        private System.Windows.Forms.Label startTimeLabel;
        private System.Windows.Forms.DateTimePicker startDateTimePicker;
        private System.Windows.Forms.Label endTimeLabel;
        private System.Windows.Forms.DateTimePicker endDateTimePicker;
        private System.Windows.Forms.ComboBox customerDropDown;
        private System.Windows.Forms.ComboBox consultantDropDown;
        private System.Windows.Forms.Label urlLabel;
        private System.Windows.Forms.TextBox urlText;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.TextBox descriptionText;
        private System.Windows.Forms.Label contactLabel;
        private System.Windows.Forms.TextBox contactText;
        private System.Windows.Forms.Label label1;
    }
}