﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace C969__Software_II
{
    public partial class AddAppointments : Form
    {
        public Appointments appointments;
        private DbHelper repo = new DbHelper();
        private TimeSpan beginningBusiness;
        private TimeSpan endBusiness;
        private bool update = false;
        private Appointment _appoingmentToUpdate;


        public AddAppointments(Appointments appointmentsMain)
        {
            beginningBusiness = new TimeSpan(8, 0, 0);
            endBusiness = new TimeSpan(17, 0, 0);
            appointments = appointmentsMain;
            InitializeComponent();
            customerDropDown.DataSource = repo.GetAllCustomers();
            consultantDropDown.DataSource = repo.GetAllUsers();
            startDateTimePicker.Format = DateTimePickerFormat.Custom;
            startDateTimePicker.CustomFormat = "MM/dd/yyyy hh:00 tt";
            endDateTimePicker.Format = DateTimePickerFormat.Custom;
            endDateTimePicker.CustomFormat = "MM/dd/yyyy hh:59 tt";
            QualityCheck();
        }

        public AddAppointments(Appointments appointmentsMain, DateTime startTime, DateTime endTime,
            string customerName, string user, string title, string location, string type, string url, string contact,
            string description)
        {
            _appoingmentToUpdate = repo.GetAppointmentToUpdate(startTime, endTime, title);
            beginningBusiness = new TimeSpan(8, 0, 0);
            endBusiness = new TimeSpan(17, 0, 0);
            appointments = appointmentsMain;
            InitializeComponent();
            customerDropDown.DataSource = repo.GetAllCustomers();
            consultantDropDown.DataSource = repo.GetAllUsers();
            startDateTimePicker.Format = DateTimePickerFormat.Custom;
            startDateTimePicker.CustomFormat = "MM/dd/yyyy hh:00 tt";
            endDateTimePicker.Format = DateTimePickerFormat.Custom;
            endDateTimePicker.CustomFormat = "MM/dd/yyyy hh:59 tt";
            startDateTimePicker.Value = startTime.ToLocalTime();
            endDateTimePicker.Value = endTime.ToLocalTime();
            customerDropDown.SelectedIndex = customerDropDown.FindStringExact(customerName);
            consultantDropDown.SelectedIndex = consultantDropDown.FindStringExact(user);
            titleText.Text = title;
            locationText.Text = location;
            typeText.Text = type;
            urlText.Text = url;
            contactText.Text = contact;
            descriptionText.Text = description;
            update = true;
            QualityCheck();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if(startDateTimePicker.Value.TimeOfDay < beginningBusiness || startDateTimePicker.Value.TimeOfDay > endBusiness || endDateTimePicker.Value.TimeOfDay > endBusiness)
            {
                AfterWorkHours ex = new AfterWorkHours();
                AppointmentException message = new AppointmentException(ex.Message);
                message.Hide();
            }
            else if(startDateTimePicker.Value > endDateTimePicker.Value)
            {
                StartGreaterThanEnd ex = new StartGreaterThanEnd();
                AppointmentException message = new AppointmentException(ex.Message);
                message.Hide();
            }
            else
            {
                try
                {
                    AddAppointment();
                    appointments.Refresh();
                    this.Close();
                }
                catch (OverflowException ex)
                {
                    AppointmentException message = new AppointmentException(ex.Message);
                    message.Show();
                }
            }
        }


        private bool CheckOverlap(List<Appointment> appointments, DateTime startTime, DateTime endTime)
        {
            //use lamda to iterate over appointments for the day to populate an IEnumerable if the new appointment start time is during an existing appointment
            IEnumerable<Appointment> checkStart = appointments.Where(x => x.startTime < startTime)
                .Where(apt => apt.endTime > startTime);

            //use lamda to iterate over appointments for the day to populate an IEnumerable if the new appointment end time is during an existing appointment
            IEnumerable<Appointment> checkEnd = appointments.Where(x => x.startTime > startTime)
                .Where(apt => apt.startTime < endTime);

            //use lamda to iterate over appointments for the day to populate an IEnumerable if the new appointment encompasses an existing appointment
            IEnumerable<Appointment> checkEncompassed = appointments.Where(apt => apt.startTime <= startTime)
                .Where(x => x.endTime >= endTime);
            if (checkStart.Any())
            {
                throw new OverflowException(message: String.Format("{1} {0}", "New appointment overlaps with customer: ", checkStart.FirstOrDefault().customerName));
            }
            else if (checkEnd.Any())
            {
                throw  new OverflowException(message: String.Format("{0} {1}", "New appointment overlaps with customer: ", checkEnd.FirstOrDefault().customerName));
            }
            else if (checkEncompassed.Any())
            {
                throw new OverflowException(message: String.Format("{1} {0}", "New appointment overlaps with customer: ", checkEncompassed.FirstOrDefault().customerName));
            }
            else
            {
                return false;
            }
        }

        private void startDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime tempStart = startDateTimePicker.Value;
            DateTime tempEnd = endDateTimePicker.Value;
            if (tempStart.ToString("d") != tempEnd.ToString("d"))
            {
                endDateTimePicker.Value = DateTime.Parse(tempStart.ToString("d") + " " + tempEnd.ToString("t"));
            }
        }

        private void endDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime tempStart = startDateTimePicker.Value;
            DateTime tempEnd = endDateTimePicker.Value;
            if (tempStart.ToString("d") != tempEnd.ToString("d"))
            {
                startDateTimePicker.Value = DateTime.Parse(tempEnd.ToString("d") + " " + tempStart.ToString("t"));
            }
        }

        private void AddAppointment()
        {
            DateTime start = DateTime.Parse(startDateTimePicker.Value.ToString("MM/dd/yyyy HH:00:00 tt")).ToUniversalTime();
            DateTime end = DateTime.Parse(endDateTimePicker.Value.ToString("MM/dd/yyyy HH:59:00 tt")).ToUniversalTime();
            DateTime checkStartDate = DateTime.Parse(start.ToString("MM/dd/yyyy 00:00:00"));
            DateTime checkEndDate = checkStartDate.AddDays(1);
            List <Appointment> check = repo.GetAppointmentsList(checkStartDate, checkEndDate);
            if (check.Any())
            {
                if (!CheckOverlap(check, startDateTimePicker.Value, endDateTimePicker.Value))
                {
                    if (update)
                    {
                        repo.UpdateAppointment(customerDropDown.SelectedValue.ToString(), consultantDropDown.SelectedValue.ToString(), titleText.Text, descriptionText.Text,
                            locationText.Text, contactText.Text, typeText.Text, urlText.Text, start, end, appointments.landing.currentUser, _appoingmentToUpdate.appointmentId);
                    }
                    else
                    {
                        repo.AddAppointment(customerDropDown.SelectedValue.ToString(), consultantDropDown.SelectedValue.ToString(), titleText.Text, descriptionText.Text,
                            locationText.Text, contactText.Text, typeText.Text, urlText.Text, start, end, appointments.landing.currentUser);
                    }
                }
            }
            else
            {
                if (update)
                {
                    repo.UpdateAppointment(customerDropDown.SelectedValue.ToString(), consultantDropDown.SelectedValue.ToString(), titleText.Text, descriptionText.Text,
                        locationText.Text, contactText.Text, typeText.Text, urlText.Text, start, end, appointments.landing.currentUser, _appoingmentToUpdate.appointmentId);
                }
                else
                {
                    repo.AddAppointment(customerDropDown.SelectedValue.ToString(), consultantDropDown.SelectedValue.ToString(), titleText.Text, descriptionText.Text,
                        locationText.Text, contactText.Text, typeText.Text, urlText.Text, start, end, appointments.landing.currentUser);
                }
            }
        }


        private void QualityCheck()
        {
            if (titleText.BackColor == System.Drawing.Color.Tan ||
                locationText.BackColor == System.Drawing.Color.Tan ||
                typeText.BackColor == System.Drawing.Color.Tan ||
                urlText.BackColor == System.Drawing.Color.Tan ||
                contactText.BackColor == System.Drawing.Color.Tan ||
                descriptionText.BackColor == System.Drawing.Color.Tan)
            {
                saveButton.Enabled = false;
            }
            else
            {
                saveButton.Enabled = true;
            }
        }

        private void TitleText_TextChanged(object sender, EventArgs e)
        {
            titleText.BackColor = titleText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Tan;
            QualityCheck();
        }

        private void LocationText_TextChanged(object sender, EventArgs e)
        {
            locationText.BackColor = locationText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Tan;
            QualityCheck();
        }

        private void TypeText_TextChanged(object sender, EventArgs e)
        {
            typeText.BackColor = typeText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Tan;
            QualityCheck();
        }

        private void UrlText_TextChanged(object sender, EventArgs e)
        {
            urlText.BackColor = Regex.IsMatch(urlText.Text, "http://") && urlText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Tan;
            QualityCheck();
        }

        private void ContactText_TextChanged(object sender, EventArgs e)
        {
            contactText.BackColor = contactText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Tan;
            QualityCheck();
        }

        private void DescriptionText_TextChanged(object sender, EventArgs e)
        {
            descriptionText.BackColor = descriptionText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Tan;
            QualityCheck();
        }
    }

    [Serializable]
    class OverlapException : Exception
    {
        public OverlapException()
        {
            
            MessageBox.Show(text: "Scheduling conflict! Please choose an available time.");
        }

        public OverlapException(string message) 
            : base (message)
        {

        }
    }

    [Serializable]
    class AfterWorkHours : Exception
    {
        public AfterWorkHours()
        {
            MessageBox.Show(text: "Please check that times are within normal business hours:"
                            + Environment.NewLine + "Monday - Friday: 8AM-5PM");
        }

        public AfterWorkHours(string message)
            : base(message)
        {
           
        }
    }

    [Serializable]
    class StartGreaterThanEnd : Exception
    {
        public StartGreaterThanEnd()
        {
            MessageBox.Show(text: "Start times can not be later than or equal to end time.");
        }

        public StartGreaterThanEnd(string message)
            : base(message)
        {

        }
    }
}
