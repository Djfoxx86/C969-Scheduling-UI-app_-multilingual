﻿using System;
using System.Globalization;
using System.IO;
using System.Windows.Forms;


namespace C969__Software_II
{
    public partial class Login : Form
    {
        public string currentUser;
        DbHelper repo = new DbHelper();
        public string errorMessage = "The username and password did not match. Please try again...";

        public Login()
        {
            InitializeComponent();
            showCorrectLang();
        }

        private void showCorrectLang()
        {
            switch (RegionInfo.CurrentRegion.EnglishName)//The full name of the country/region in English.
            {
                case "United States":
                    showEnglish();
                    break;
                case "Mexico":
                    showSpanish();
                    break;

                default:
                    showEnglish();
                    break;
            }
        }

        private void showEnglish()
        {
            titleLabel.Text = "Please login below.";
            usernameLabel.Text = "Username";
            passwordLabel.Text = "Password";
            loginButton.Text = "Log in";
            cancelButton.Text = "Cancel";
            errorMessage = "The username and password did not match.";
        }

        private void showSpanish()
        {
                titleLabel.Text = "Por favor inicie sesión abajo"; //Please login below
                usernameLabel.Text = "Nombre de usuario";  //Username
                passwordLabel.Text = "Contraseña"; //Password
                loginButton.Text = "Iniciar sesión"; //Log in
                cancelButton.Text = "Cancelar"; //Cancel
                errorMessage = "El nombre de usuario y la contraseña no coinciden."; //The username and password did not match
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string loginResults = repo.Login(usernameTextBox.Text, passwordTextBox.Text);
            if (loginResults == "True")
            {
                currentUser = usernameTextBox.Text;
                WriteToLog(currentUser);
                this.Hide();
                Appointments appointmentsForm = new Appointments(this);
                appointmentsForm.Closed += (s, args) => this.Close();
                appointmentsForm.Show();
            }
            else
            {
                MessageBox.Show(errorMessage);
                passwordTextBox.Text = "";
            }
        }


        private void WriteToLog(string user)
        {
            string path = System.IO.Path.GetFullPath(@"..\..\logs");
            path += @"\log.txt";
            {
                string log = $"User with ID of {user} logged in at {DbHelper.createLogTimestamp()}" + Environment.NewLine;
                File.AppendAllText(path, log);
            }
        }


        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
