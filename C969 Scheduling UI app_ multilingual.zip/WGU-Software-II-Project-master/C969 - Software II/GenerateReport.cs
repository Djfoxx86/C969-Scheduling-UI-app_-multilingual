﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchedulingAssistant
{
    public partial class GenerateReport : Form
    {
        DbRepository repo = new DbRepository();
        private Languages _languages;
        private int _reportType;
        public GenerateReport(int reportType, Languages language)
        {
            _languages = language;
            _reportType = reportType;
            InitializeComponent();
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "MM/yyyy";
            if (_reportType == 1)
            {
                comboBox1.Hide();
                label1.Text = "Select Month To Report On";
            }
            else if (_reportType == 2)
            {
                dateTimePicker1.Hide();
                comboBox1.DataSource = repo.GetAllUsers();
                label1.Text = "Select Consultant To Report On";
            }
            else if (_reportType == 3)
            {
                dateTimePicker1.Hide();
                comboBox1.DataSource = repo.GetAllCustomers();
                label1.Text = "Select Customer To Report On";
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void generate_Click(object sender, EventArgs e)
        {
            if (_reportType == 1)
            {
                DateTime reportTime = DateTime.Parse(dateTimePicker1.Value.ToString("MM/yyyy"));
                DateTime startDate = new DateTime(reportTime.Year, reportTime.Month, 1).ToUniversalTime();
                DateTime endDate = startDate.AddMonths(1).AddDays(-1).ToUniversalTime();
                List<ReportItem> results = repo.GetNumberOfAppointmentTypeByMonth(startDate, endDate);
                string path = GenerateTypesByMonthResults(results, "AppointmentTypesByMonth");
                this.Hide();
                AlertMessage alert = new AlertMessage(String.Format("Report generated to following path: {0}", path), _languages);
                alert.Closed += (s, args) => this.Close();
                alert.Show();
            }
            else if (_reportType == 2)
            {
                int userId = repo.GetUserId(comboBox1.SelectedValue.ToString());
                List<Appointment> results = repo.GetAppointmentsByUser(userId);
                string path = GenerateAppointmentResults(results, String.Format("{0}Appointments", comboBox1.SelectedValue.ToString()));
                this.Hide();
                AlertMessage alert = new AlertMessage(String.Format("Report generated to following path: {0}", path), _languages);
                alert.Closed += (s, args) => this.Close();
                alert.Show();
            }
            else if (_reportType == 3)
            {
                int customerId = repo.GetCustomerId(comboBox1.SelectedValue.ToString());
                List<Appointment> results = repo.GetAppointmentsByCustomer(customerId);
                string path = GenerateAppointmentResults(results, String.Format("{0}Appointments", comboBox1.SelectedValue.ToString()));
                this.Hide();
                AlertMessage alert = new AlertMessage(String.Format("Report generated to following path: {0}", path), _languages);
                alert.Closed += (s, args) => this.Close();
                alert.Show();
            }
        }

        private string GenerateAppointmentResults(List<Appointment> apt, string report)
        {
            DateTime reportTime = DateTime.Now;
            string path = System.IO.Path.GetFullPath(@"..\..\Reports");
            path += String.Format(@"\{1}_{0}.txt", reportTime.ToString("yyyyMMdd_HHmmss"), report);
            
            AppointmentListToCSV(apt, path);
            return path;
        }

        private string GenerateTypesByMonthResults(List<ReportItem> repList, string report)
        {
            DateTime reportTime = DateTime.Now;
            string path = System.IO.Path.GetFullPath(@"..\..\Reports");
            path += String.Format(@"\{1}_{0}.txt", reportTime.ToString("yyyyMMdd_HHmmss"), report);
            
            ReportItemListToCSV(repList, path);
            return path;
        }

        public void AppointmentListToCSV(List<Appointment> aptList, string strFilePath)
        {
            using (StreamWriter sw = File.CreateText(strFilePath))
            {
                //headers  
                sw.Write("Start,");
                sw.Write("End,");
                sw.Write("Customer,");
                sw.Write("Consultant,");
                sw.Write("Title,");
                sw.Write("Type,");
                sw.Write("Contact,");
                sw.Write("Location,");
                sw.Write("URL,");
                sw.Write("Description");
                sw.Write(sw.NewLine);
                foreach (var apt in aptList)
                {
                    sw.Write(WrapValue(apt.startTime.ToString()) + ",");
                    sw.Write(WrapValue(apt.endTime.ToString()) + ",");
                    sw.Write(WrapValue(apt.customerName) + ",");
                    sw.Write(WrapValue(apt.user) + ",");
                    sw.Write(WrapValue(apt.title) + ",");
                    sw.Write(WrapValue(apt.aptType) + ",");
                    sw.Write(WrapValue(apt.contact) + ",");
                    sw.Write(WrapValue(apt.location) + ",");
                    sw.Write(WrapValue(apt.url) + ",");
                    sw.Write(WrapValue(apt.description));
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
        }

        public void ReportItemListToCSV(List<ReportItem> repList, string strFilePath)
        {
            using (StreamWriter sw = File.CreateText(strFilePath))
            {
                //headers  
                sw.Write("Count,");
                sw.Write("Type");
                sw.Write(sw.NewLine);
                foreach (var rep in repList)
                {
                    sw.Write(WrapValue(rep.num.ToString()));
                    sw.Write(WrapValue(rep.type));
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
        }

        public string WrapValue(string val)
        {
            return String.Format("\"{0}\"", val);
        }
    }
}
