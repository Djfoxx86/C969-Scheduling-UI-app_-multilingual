﻿using System;

namespace SchedulingAssistant
{
    public class Appointment
    {
        public string title;
        public DateTime startTime;
        public DateTime endTime;
        public string description;
        public string location;
        public string contact;
        public string url;
        public string customerName;
        public string user;
        public string aptType;
        public int appointmentId;
    }
}
