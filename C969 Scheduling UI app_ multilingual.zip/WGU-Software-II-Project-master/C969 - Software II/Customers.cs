﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SchedulingAssistant
{
    public partial class Customers : Form
    {
        DbRepository repo = new DbRepository();
        public Appointments appointments;
        private Languages _languages;
        public Customers(Appointments appointmentsMain, Languages language)
        {
            _languages = language;
            appointments = appointmentsMain;
            InitializeComponent();
            dgvCustomers.RowHeadersVisible = false;
            dgvCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCustomers.DataSource = repo.GetCustomerData();
            SetLanguage();
        }

        private void addCustomer_Click(object sender, EventArgs e)
        {
            AddCustomer addCustomer = new AddCustomer(this, _languages);
            addCustomer.Show();
        }

        public override void Refresh()
        {
            dgvCustomers.DataSource = repo.GetCustomerData();
            base.Refresh();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            var customerName = dgvCustomers.SelectedCells[1].Value.ToString();
            var customerId = repo.GetCustomerId(customerName);
            repo.DeleteCustomerRecord(customerId);
            dgvCustomers.DataSource = repo.GetCustomerData();
        }

        private void update_Click(object sender, EventArgs e)
        {
            var customerName = dgvCustomers.SelectedCells[1].Value.ToString();
            var customerId = repo.GetCustomerId(customerName);
            Dictionary<string, string> customer = repo.GetCustomerDataToUpdate(customerId);
            AddCustomer addCustomer = new AddCustomer(this, customer["customerName"], customer["address"], customer["address2"], 
                customer["postalCode"], customer["phone"], customer["city"], customer["country"], customer["active"], customerId, _languages);
            addCustomer.Show();
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SetLanguage()
        {
            addCustomer.Text = _languages.add;
            update.Text = _languages.update;
            delete.Text = _languages.delete;
            cancel.Text = _languages.cancel;
            this.Text = _languages.customers;
        }
    }
}
