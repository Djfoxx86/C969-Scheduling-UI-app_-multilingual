﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C969__Software_II
{
    public class ReportItem
    {
        public int num;
        public string type;
    }
}
