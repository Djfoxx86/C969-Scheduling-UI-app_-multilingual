﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Data;
using System.Configuration;

namespace C969__Software_II
{
    public class DbHelper
    {
        private string _connectionString;
        private MySqlConnection _connection;


        public void OpenConnection()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["MySQLConn"].ConnectionString;
            _connection = new MySqlConnection(_connectionString);
            _connection.Open();
        }

        public void CloseConnection()
        {
            _connection.Close();
        }

        public static string createLogTimestamp()
        {
            return DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt");
        }
        public DataTable GetData(string query)
        {
            OpenConnection();
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand(query, _connection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(selectCommand: cmd);
            adapter.Fill(dt);
            CloseConnection();
            return dt;
        }

        public void WriteData(string query)
        {
            MySqlCommand cmd = new MySqlCommand(query, _connection);
            cmd.ExecuteNonQuery();
        }

        public string Login(string userName, string password)
        {
            OpenConnection();
            string query = "SELECT password FROM user WHERE userName = @username";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@userName", userName);
            cmd.Connection = _connection;
            string queryPassword = Convert.ToString(cmd.ExecuteScalar());
            CloseConnection();

            if (queryPassword == password)
            {
                return "True";
            }

            return "Nope";
        }

        public void DeleteCustomerRecord(int customerId)
        {
            List<string> appointments = this.HasAppointment(customerId);
            if (appointments[0] != "null")
            {
                DeleteAppointments(appointments);

            }

            OpenConnection();
            string query = "DELETE FROM customer WHERE customerId = @customerId";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public List<string> HasAppointment(int customerId)
        {
            OpenConnection();
            string query = "SELECT appointmentId FROM appointment WHERE customerId = @customerId";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            List<string> result = new List<string>();
            MySqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.HasRows)
                {
                    reader.Read();
                    result.Add(reader.GetString(0));
                    reader.NextResult();
                }
            }
            else
            {
                result.Add("null");
            }

            CloseConnection();

            return result;
        }

        public void DeleteAppointments(List<string> appintmentIds)
        {
            OpenConnection();
            string clause = string.Join(",", appintmentIds.ToArray());
            string query = "DELETE FROM appointment WHERE appointmentId IN (@whereClause)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@whereClause", clause);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public void AddCountry(string country, string user)
        {
            OpenConnection();
            string query =
                "INSERT INTO country(country, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@country, @createDate, @createdBy, @lastUpdate, @lastUpdatedBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@country", country);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdatedBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();

        }

        public int GetCountryId(string country)
        {
            OpenConnection();
            string query = "SELECT countryId FROM country WHERE country = @country ORDER BY countryId DESC LIMIT 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@country", country);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public void AddCity(string city, int countryId, string user)
        {
            OpenConnection();
            string query =
                "INSERT INTO city(city, countryId, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@city, @countryId, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Parameters.AddWithValue("@countryId", countryId);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();

        }

        public int GetCityId(string city)
        {
            OpenConnection();
            string query = "SELECT cityId FROM city WHERE city = @city ORDER BY cityId DESC LIMIT 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public void AddAddress(string address, string address2, string postalCode, string phone, string city,
            string country, string user)
        {
            AddCountry(country, user);
            int countryId = GetCountryId(country);
            AddCity(city, countryId, user);
            int cityId = GetCityId(city);
            OpenConnection();
            string query =
                "INSERT INTO address(address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@address, @address2, @cityId, @postalCode, @phone, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@address2", address2);
            cmd.Parameters.AddWithValue("@cityId", cityId);
            cmd.Parameters.AddWithValue("@postalCode", postalCode);
            cmd.Parameters.AddWithValue("@phone", phone);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public int GetAddressId(string address, string address2, string postalCode, string phone)
        {
            OpenConnection();
            string query = "SELECT addressId FROM address " +
                           "WHERE address = @address AND address2 = @address2 AND postalCode = @postalCode AND phone = @phone ORDER BY addressId DESC LIMIT 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@address2", address2);
            cmd.Parameters.AddWithValue("@postalCode", postalCode);
            cmd.Parameters.AddWithValue("@phone", phone);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public DataTable GetCustomerData()
        {
            string query =
                "SELECT active AS 'Active', customerName AS 'Name', address AS 'Address', address2 AS 'Address2', postalcode AS 'Postal Code', phone AS 'Phone', city AS 'City', country AS 'Country' " +
                "FROM customer " +
                "JOIN address ON customer.addressId = address.addressId " +
                "JOIN city ON city.cityId = address.cityId " +
                "JOIN country ON country.countryId = city.countryId";
            return GetData(query);
        }

        public int GetCustomerId(string customerName)
        {
            OpenConnection();
            string query = "SELECT customerId FROM customer WHERE customerName = @customerName";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerName", customerName);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public void AddCustomer(string customerName, string address, string address2, string postalCode, string phone,
            string city, string country, bool active, string user)
        {
            int isActive = active ? 1 : 0;
            AddAddress(address, address2, postalCode, phone, city, country, user);
            int addressId = GetAddressId(address, address2, postalCode, phone);
            OpenConnection();
            string query =
                "INSERT INTO customer(customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@customerName, @addressId, @active, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerName", customerName);
            cmd.Parameters.AddWithValue("@addressId", addressId);
            cmd.Parameters.AddWithValue("@active", isActive);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public Dictionary<string, string> GetCustomerDataToUpdate(int customerId)
        {
            Dictionary<string, string> results = new Dictionary<string, string>();
            string query = "SELECT active, customerName, address, address2, postalCode, phone, city, country " +
                           "FROM customer " +
                           "JOIN address ON customer.addressId = address.addressId " +
                           "JOIN city ON city.cityId = address.cityId " +
                           "JOIN country ON country.countryId = city.countryId " +
                           "WHERE customerId = @customerId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    results.Add("active", myReader.GetInt32("active").ToString());
                    results.Add("customerName", myReader.GetString("customerName"));
                    results.Add("address", myReader.GetString("address"));
                    results.Add("address2", myReader.GetString("address2"));
                    results.Add("postalCode", myReader.GetString("postalCode"));
                    results.Add("phone", myReader.GetString("phone"));
                    results.Add("city", myReader.GetString("city"));
                    results.Add("country", myReader.GetString("country"));
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public void UpdateCountry(int countryId, string country, string user)
        {
            string query = "UPDATE country " +
                           "SET country = @country, " +
                           "lastUpdateBy = @user, " +
                           "lastUpdate = @now " +
                           "WHERE countryId = @countryId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@country", country);
            cmd.Parameters.AddWithValue("@user", user);
            cmd.Parameters.AddWithValue("@now", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@countryId", countryId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public void UpdateCity(int cityId, string city, string user)
        {
            string query = "UPDATE city " +
                           "SET city = @city, " +
                           "lastUpdateBy = @user, " +
                           "lastUpdate = @now " +
                           "WHERE cityId = @cityId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Parameters.AddWithValue("@user", user);
            cmd.Parameters.AddWithValue("@now", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@cityId", cityId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public void UpdateAddress(int addressId, string address, string address2, string postalCode, string phone,
            string user)
        {
            string query = "UPDATE address " +
                           "SET address = @address, " +
                           "address2 = @address2, " +
                           "postalCode = @postalCode, " +
                           "phone = @phone, " +
                           "lastUpdateBy = @user, " +
                           "lastUpdate = @now " +
                           "WHERE addressId = @addressId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@address2", address2);
            cmd.Parameters.AddWithValue("@postalCode", postalCode);
            cmd.Parameters.AddWithValue("@phone", phone);
            cmd.Parameters.AddWithValue("@user", user);
            cmd.Parameters.AddWithValue("@now", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@addressId", addressId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public Dictionary<string, int> GetCustomerDataIdsToUpdate(int customerId)
        {
            Dictionary<string, int> results = new Dictionary<string, int>();
            string query = "SELECT address.addressId, city.cityId, country.countryId " +
                           "FROM customer " +
                           "JOIN address ON customer.addressId = address.addressId " +
                           "JOIN city ON city.cityId = address.cityId " +
                           "JOIN country ON country.countryId = city.countryId " +
                           "WHERE customerId = @customerId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    results.Add("addressId", myReader.GetInt32("addressId"));
                    results.Add("cityId", myReader.GetInt32("cityId"));
                    results.Add("countryId", myReader.GetInt32("countryId"));
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public void UpdateCustomer(int customerId, int addressId, int cityId, int countryId, string customerName,
            string address, string address2, string postalCode, string phone, string city, string country, bool active,
            string user)
        {
            int isActive = active == true ? 1 : 0;
            UpdateCountry(countryId, country, user);
            UpdateCity(cityId, city, user);
            UpdateAddress(addressId, address, address2, postalCode, phone, user);
            OpenConnection();
            string query = "UPDATE customer " +
                           "SET customerName = @customerName, " +
                           "active = @isActive, " +
                           "lastUpdate = @now, " +
                           "lastUpdateBy = @user " +
                           "WHERE customerId = @customerId";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerName", customerName);
            cmd.Parameters.AddWithValue("@isActive", isActive);
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Parameters.AddWithValue("@now", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@user", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public List<string> GetAllCustomers()
        {
            List<string> results = new List<string>();
            OpenConnection();
            string query = "SELECT customerName FROM customer WHERE active = 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    results.Add(myReader.GetString("customerName"));
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public List<string> GetAllUsers()
        {
            List<string> results = new List<string>();
            OpenConnection();
            string query = "SELECT userName FROM user WHERE active = 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    results.Add(myReader.GetString("userName"));
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public int GetUserId(string userName)
        {
            OpenConnection();
            string query = "SELECT userId FROM user WHERE userName = @userName";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@userName", userName);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public void AddAppointment(string customerName, string userName, string title, string description,
            string location, string contact, string type, string url, DateTime start, DateTime end, string user)
        {
            int customerId = GetCustomerId(customerName);
            int userId = GetUserId(userName);
            OpenConnection();
            string query =
                "INSERT INTO appointment(customerId, userId, title, description, location, contact, type, url, start, end, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@customerId, @userId, @title, @description, @location, @contact, @type, @url, @start, @end, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@description", description);
            cmd.Parameters.AddWithValue("@location", location);
            cmd.Parameters.AddWithValue("@contact", contact);
            cmd.Parameters.AddWithValue("@type", type);
            cmd.Parameters.AddWithValue("@url", url);
            cmd.Parameters.AddWithValue("@start", start);
            cmd.Parameters.AddWithValue("@end", end);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public List<Appointment> GetAppointmentsList(DateTime startDate, DateTime endDate)
        {
            List<Appointment> results = new List<Appointment>();
            OpenConnection();
            string query =
                "SELECT contact, title, description, location, type, url, start, end, customerName, userName FROM appointment " +
                "JOIN customer ON customer.customerId = appointment.customerId " +
                "JOIN user ON user.userId = appointment.userId " +
                "WHERE appointment.start > @startDate " +
                "AND appointment.end < @endDate " +
                "ORDER BY appointment.start";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@startDate", startDate);
            cmd.Parameters.AddWithValue("@endDate", endDate);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    Appointment apt = new Appointment();
                    apt.title = myReader.GetString("title");
                    apt.startTime = myReader.GetDateTime("start").ToLocalTime();
                    apt.endTime = myReader.GetDateTime("end").ToLocalTime();
                    apt.contact = myReader.GetString("contact");
                    apt.customerName = myReader.GetString("customerName");
                    apt.description = myReader.GetString("description");
                    apt.location = myReader.GetString("location");
                    apt.aptType = myReader.GetString("type");
                    apt.url = myReader.GetString("url");
                    apt.user = myReader.GetString("userName");
                    results.Add(apt);
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public bool DoesCustomerExist(string customerName)
        {
            OpenConnection();
            string query = "SELECT 1 FROM customer " +
                           "WHERE customerName = @customerName";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerName", customerName);
            cmd.Connection = _connection;
            string result = Convert.ToString(cmd.ExecuteScalar());
            CloseConnection();
            return result == "1";
        }

        public void UpdateAppointment(string customerName, string userName, string title, string description,
            string location, string contact, string type, string url, DateTime start, DateTime end, string user, int appointmentId)
        {
            int customerId = GetCustomerId(customerName);
            int userId = GetUserId(userName);
            OpenConnection();
            string query =
                "UPDATE appointment " +
                "SET customerId = @customerId, " +
                "userId = @userId, " +
                "title = @title, " +
                "description = @description, " +
                "location = @location, " +
                "contact = @contact, " +
                "type = @type, " +
                "url = @url, " +
                "start = @start, " +
                "end = @end, " +
                "lastUpdate = @lastUpdate, " +
                "lastUpdateBy = @lastUpdateBy " +
                "WHERE appointmentId = @appointmentId";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@description", description);
            cmd.Parameters.AddWithValue("@location", location);
            cmd.Parameters.AddWithValue("@contact", contact);
            cmd.Parameters.AddWithValue("@type", type);
            cmd.Parameters.AddWithValue("@url", url);
            cmd.Parameters.AddWithValue("@start", DateTime.Parse(start.ToString("MM/dd/yyyy hh:mm tt")));
            cmd.Parameters.AddWithValue("@end", DateTime.Parse(end.ToString("MM/dd/yyyy hh:mm tt")));
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Parameters.AddWithValue("@appointmentId", appointmentId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();

        }

        public Appointment GetAppointmentToUpdate(DateTime startDate, DateTime endDate, string title)
        {
            Appointment results = new Appointment();
            OpenConnection();
            string query =
                "SELECT appointmentId, contact, title, description, location, type, url, start, end, customerName, userName FROM appointment " +
                "JOIN customer ON customer.customerId = appointment.customerId " +
                "JOIN user ON user.userId = appointment.userId " +
                "WHERE appointment.start = @startDate " +
                "AND appointment.end = @endDate " +
                "AND appointment.title = @title";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@startDate", startDate);
            cmd.Parameters.AddWithValue("@endDate", endDate);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    Appointment apt = new Appointment();
                    apt.title = myReader.GetString("title");
                    apt.startTime = myReader.GetDateTime("start");
                    apt.endTime = myReader.GetDateTime("end");
                    apt.contact = myReader.GetString("contact");
                    apt.customerName = myReader.GetString("customerName");
                    apt.description = myReader.GetString("description");
                    apt.location = myReader.GetString("location");
                    apt.aptType = myReader.GetString("type");
                    apt.url = myReader.GetString("url");
                    apt.user = myReader.GetString("userName");
                    apt.appointmentId = myReader.GetInt32("appointmentId");
                    results = apt;
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public void DeleteAppointment(DateTime start, DateTime end, string title)
        {
            OpenConnection();
            string query = "DELETE FROM appointment WHERE start = @start AND end = @end AND title = @title";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@start", start);
            cmd.Parameters.AddWithValue("@end", end);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public List<ReportItem> GetNumberOfAppointmentTypeByMonth(DateTime start, DateTime end)
        {
            List<ReportItem> results = new List<ReportItem>();
            OpenConnection();
            string query = "SELECT count(*) AS 'Count', type AS 'Type' FROM appointment WHERE start >= @start AND end <= @end GROUP BY type";
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@start", start);
            cmd.Parameters.AddWithValue("@end", end);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    ReportItem repItem = new ReportItem();
                    repItem.num = myReader.GetInt32("Count");
                    repItem.type = myReader.GetString("Type");
                    results.Add(repItem);
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public List<Appointment> GetAppointmentsByUser(int userId)
        {
            List<Appointment> results = new List<Appointment>();
            OpenConnection();
            string query =
                "SELECT contact, title, description, location, type, url, start, end, customerName, userName FROM appointment " +
                "JOIN customer ON customer.customerId = appointment.customerId " +
                "JOIN user ON user.userId = appointment.userId " +
                "WHERE user.userId = @userId";
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    Appointment apt = new Appointment();
                    apt.title = myReader.GetString("title");
                    apt.startTime = myReader.GetDateTime("start").ToLocalTime();
                    apt.endTime = myReader.GetDateTime("end").ToLocalTime();
                    apt.contact = myReader.GetString("contact");
                    apt.customerName = myReader.GetString("customerName");
                    apt.description = myReader.GetString("description");
                    apt.location = myReader.GetString("location");
                    apt.aptType = myReader.GetString("type");
                    apt.url = myReader.GetString("url");
                    apt.user = myReader.GetString("userName");
                    results.Add(apt);
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }


 
               


        public List<Appointment> GetAppointmentsByCustomer(int customerId)
        {
            List<Appointment> results = new List<Appointment>();
            OpenConnection();
            string query =
                "SELECT contact, title, description, location, type, url, start, end, customerName, userName FROM appointment " +
                "JOIN customer ON customer.customerId = appointment.customerId " +
                "JOIN user ON user.userId = appointment.userId " +
                "WHERE customer.customerId = @customerId";
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    Appointment apt = new Appointment();
                    apt.title = myReader.GetString("title");
                    apt.startTime = myReader.GetDateTime("start").ToLocalTime();
                    apt.endTime = myReader.GetDateTime("end").ToLocalTime();
                    apt.contact = myReader.GetString("contact");
                    apt.customerName = myReader.GetString("customerName");
                    apt.description = myReader.GetString("description");
                    apt.location = myReader.GetString("location");
                    apt.aptType = myReader.GetString("type");
                    apt.url = myReader.GetString("url");
                    apt.user = myReader.GetString("userName");
                    results.Add(apt);
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }
    }
}