﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulingAssistant.Class
{
    class appointmentException : ApplicationException
    {
        public void businessHours()
        {
            MessageBox.Show("Please check that times are within normal business hours.");
        }

        public void appOverlap()
        {
            MessageBox.Show("Scheduling conflict! Please choose an available time.");
        }
    }
}
