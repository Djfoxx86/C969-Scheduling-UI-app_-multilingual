﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C969__Software_II
{
    public class Languages
    {
        public string Login;
        public string userName;
        public string password;
        public string logOnError;
        public string close;
        public string exit;


        public void English()
        {
            Login = "Login";
            userName = "Username";
            password = "Password";
            logOnError = "The username and password did not match.";
            close = "Close";
            exit = "Exit";

        }

        public void Spanish()
        {
            Login = "Acceso";
            userName = "Nombre de Usuario";
            password = "Contraseña";
            logOnError = "El nombre de usuario y la contraseña no coinciden.";
            close = "Cerca";
            exit = "Salida";
        }
    }
}
