﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchedulingAssistant
{
    public partial class AlertMessage : Form
    {
        public AlertMessage(string message, Languages language)
        {
            InitializeComponent();
            textBox1.ReadOnly = true;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Text = message;
            textBox1.TabStop = false;
        }

        private void dismiss_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
