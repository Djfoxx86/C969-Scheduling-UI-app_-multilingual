﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Data;
using System.Configuration;

namespace SchedulingAssistant
{
    public class DbRepository
    {
        private string _connectionString;
        private MySqlConnection _connection;

        public void OpenConnection()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["MySQLConn"].ConnectionString;
            _connection = new MySqlConnection(_connectionString);
            _connection.Open();
        }

        public void CloseConnection()
        {
            _connection.Close();
        }

        public DataTable GetData(string query)
        {
            OpenConnection();
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand(query, _connection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(selectCommand: cmd);
            adapter.Fill(dt);
            CloseConnection();
            return dt;
        }

        public void WriteData(string query)
        {
            MySqlCommand cmd = new MySqlCommand(query, _connection);
            cmd.ExecuteNonQuery();
        }

        public string SignOn(string userName, string password)
        {
            OpenConnection();
            string query = "select password from user " +
                           "where userName = @username";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@userName", userName);
            cmd.Connection = _connection;
            string queryPassword = Convert.ToString(cmd.ExecuteScalar());
            CloseConnection();

            if (queryPassword == password)
            {
                return "True";
            }

            return "Nope";
        }

        public void DeleteCustomerRecord(int customerId)
        {
            List<string> appointments = this.HasAppointment(customerId);
            if (appointments[0] != "null")
            {
                DeleteAppointments(appointments);

            }

            OpenConnection();
            string query = "delete from customer " +
                           "where customerId = @customerId";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public List<string> HasAppointment(int customerId)
        {
            OpenConnection();
            string query = "select appointmentId from appointment " +
                           "where customerId = @customerId";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            List<string> result = new List<string>();
            MySqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.HasRows)
                {
                    reader.Read();
                    result.Add(reader.GetString(0));
                    reader.NextResult();
                }
            }
            else
            {
                result.Add("null");
            }

            CloseConnection();

            return result;
        }

        public void DeleteAppointments(List<string> appintmentIds)
        {
            OpenConnection();
            string clause = string.Join(",", appintmentIds.ToArray());
            string query = "delete from appointment " +
                           "where appointmentId in (@whereClause)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@whereClause", clause);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public void AddCountry(string country, string user)
        {
            OpenConnection();
            string query =
                "insert into country(country, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@country, @createDate, @createdBy, @lastUpdate, @lastUpdatedBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@country", country);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdatedBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();

        }

        public int GetCountryId(string country)
        {
            OpenConnection();
            string query = "select countryId from country " +
                           "where country = @country order by countryId desc LIMIT 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@country", country);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public void AddCity(string city, int countryId, string user)
        {
            OpenConnection();
            string query =
                "insert into city(city, countryId, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@city, @countryId, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Parameters.AddWithValue("@countryId", countryId);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();

        }

        public int GetCityId(string city)
        {
            OpenConnection();
            string query = "select cityId from city " +
                           "where city = @city order by cityId desc LIMIT 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public void AddAddress(string address, string address2, string postalCode, string phone, string city,
            string country, string user)
        {
            AddCountry(country, user);
            int countryId = GetCountryId(country);
            AddCity(city, countryId, user);
            int cityId = GetCityId(city);
            OpenConnection();
            string query =
                "insert into address(address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@address, @address2, @cityId, @postalCode, @phone, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@address2", address2);
            cmd.Parameters.AddWithValue("@cityId", cityId);
            cmd.Parameters.AddWithValue("@postalCode", postalCode);
            cmd.Parameters.AddWithValue("@phone", phone);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public int GetAddressId(string address, string address2, string postalCode, string phone)
        {
            OpenConnection();
            string query = "select addressId from address " +
                           "where address = @address and address2 = @address2 and postalCode = @postalCode and phone = @phone order by addressId desc LIMIT 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@address2", address2);
            cmd.Parameters.AddWithValue("@postalCode", postalCode);
            cmd.Parameters.AddWithValue("@phone", phone);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public DataTable GetCustomerData()
        {
            string query =
                "select active as 'Active', customerName as 'Name', address as 'Address', address2 as 'Address2', postalcode as 'Postal Code', phone as 'Phone', city as 'City', country as 'Country' " +
                "from customer " +
                "join address on customer.addressId = address.addressId " +
                "join city on city.cityId = address.cityId " +
                "join country on country.countryId = city.countryId";
            return GetData(query);
        }

        public int GetCustomerId(string customerName)
        {
            OpenConnection();
            string query = "select customerId from customer " +
                           "where customerName = @customerName";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerName", customerName);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public void AddCustomer(string customerName, string address, string address2, string postalCode, string phone,
            string city, string country, bool active, string user)
        {
            int isActive = active ? 1 : 0;
            AddAddress(address, address2, postalCode, phone, city, country, user);
            int addressId = GetAddressId(address, address2, postalCode, phone);
            OpenConnection();
            string query =
                "insert into customer(customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@customerName, @addressId, @active, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerName", customerName);
            cmd.Parameters.AddWithValue("@addressId", addressId);
            cmd.Parameters.AddWithValue("@active", isActive);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public Dictionary<string, string> GetCustomerDataToUpdate(int customerId)
        {
            Dictionary<string, string> results = new Dictionary<string, string>();
            string query = "select active, customerName, address, address2, postalCode, phone, city, country " +
                           "from customer " +
                           "join address on customer.addressId = address.addressId " +
                           "join city on city.cityId = address.cityId " +
                           "join country on country.countryId = city.countryId " +
                           "where customerId = @customerId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    results.Add("active", myReader.GetInt32("active").ToString());
                    results.Add("customerName", myReader.GetString("customerName"));
                    results.Add("address", myReader.GetString("address"));
                    results.Add("address2", myReader.GetString("address2"));
                    results.Add("postalCode", myReader.GetString("postalCode"));
                    results.Add("phone", myReader.GetString("phone"));
                    results.Add("city", myReader.GetString("city"));
                    results.Add("country", myReader.GetString("country"));
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public void UpdateCountry(int countryId, string country, string user)
        {
            string query = "update country " +
                           "set country = @country, " +
                           "lastUpdateBy = @user, " +
                           "lastUpdate = @now " +
                           "where countryId = @countryId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@country", country);
            cmd.Parameters.AddWithValue("@user", user);
            cmd.Parameters.AddWithValue("@now", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@countryId", countryId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public void UpdateCity(int cityId, string city, string user)
        {
            string query = "update city " +
                           "set city = @city, " +
                           "lastUpdateBy = @user, " +
                           "lastUpdate = @now " +
                           "where cityId = @cityId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Parameters.AddWithValue("@user", user);
            cmd.Parameters.AddWithValue("@now", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@cityId", cityId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public void UpdateAddress(int addressId, string address, string address2, string postalCode, string phone,
            string user)
        {
            string query = "update address " +
                           "set address = @address, " +
                           "address2 = @address2, " +
                           "postalCode = @postalCode, " +
                           "phone = @phone, " +
                           "lastUpdateBy = @user, " +
                           "lastUpdate = @now " +
                           "where addressId = @addressId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@address2", address2);
            cmd.Parameters.AddWithValue("@postalCode", postalCode);
            cmd.Parameters.AddWithValue("@phone", phone);
            cmd.Parameters.AddWithValue("@user", user);
            cmd.Parameters.AddWithValue("@now", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@addressId", addressId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public Dictionary<string, int> GetCustomerDataIdsToUpdate(int customerId)
        {
            Dictionary<string, int> results = new Dictionary<string, int>();
            string query = "select address.addressId, city.cityId, country.countryId " +
                           "from customer " +
                           "join address on customer.addressId = address.addressId " +
                           "join city on city.cityId = address.cityId " +
                           "join country on country.countryId = city.countryId " +
                           "where customerId = @customerId";
            OpenConnection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    results.Add("addressId", myReader.GetInt32("addressId"));
                    results.Add("cityId", myReader.GetInt32("cityId"));
                    results.Add("countryId", myReader.GetInt32("countryId"));
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public void UpdateCustomer(int customerId, int addressId, int cityId, int countryId, string customerName,
            string address, string address2, string postalCode, string phone, string city, string country, bool active,
            string user)
        {
            int isActive = active == true ? 1 : 0;
            UpdateCountry(countryId, country, user);
            UpdateCity(cityId, city, user);
            UpdateAddress(addressId, address, address2, postalCode, phone, user);
            OpenConnection();
            string query = "update customer " +
                           "set customerName = @customerName, " +
                           "active = @isActive, " +
                           "lastUpdate = @now, " +
                           "lastUpdateBy = @user " +
                           "where customerId = @customerId";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerName", customerName);
            cmd.Parameters.AddWithValue("@isActive", isActive);
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Parameters.AddWithValue("@now", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@user", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public List<string> GetAllCustomers()
        {
            List<string> results = new List<string>();
            OpenConnection();
            string query = "select customerName from customer where active = 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    results.Add(myReader.GetString("customerName"));
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public List<string> GetAllUsers()
        {
            List<string> results = new List<string>();
            OpenConnection();
            string query = "select userName from user where active = 1";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    results.Add(myReader.GetString("userName"));
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public int GetUserId(string userName)
        {
            OpenConnection();
            string query = "select userId from user " +
                           "where userName = @userName";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@userName", userName);
            cmd.Connection = _connection;
            int result = (int) cmd.ExecuteScalar();
            CloseConnection();
            return result;
        }

        public void AddAppointment(string customerName, string userName, string title, string description,
            string location, string contact, string type, string url, DateTime start, DateTime end, string user)
        {
            int customerId = GetCustomerId(customerName);
            int userId = GetUserId(userName);
            OpenConnection();
            string query =
                "insert into appointment(customerId, userId, title, description, location, contact, type, url, start, end, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                "VALUES(@customerId, @userId, @title, @description, @location, @contact, @type, @url, @start, @end, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@description", description);
            cmd.Parameters.AddWithValue("@location", location);
            cmd.Parameters.AddWithValue("@contact", contact);
            cmd.Parameters.AddWithValue("@type", type);
            cmd.Parameters.AddWithValue("@url", url);
            cmd.Parameters.AddWithValue("@start", start);
            cmd.Parameters.AddWithValue("@end", end);
            cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@createdBy", user);
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public List<Appointment> GetAppointmentsList(DateTime startDate, DateTime endDate)
        {
            List<Appointment> results = new List<Appointment>();
            OpenConnection();
            string query =
                " select contact, title, description, location, type, url, start, end, customerName, userName from appointment " +
                "join customer on customer.customerId = appointment.customerId " +
                "join user on user.userId = appointment.userId " +
                "where appointment.start > @startDate " +
                "and appointment.end < @endDate " +
                "order by appointment.start";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@startDate", startDate);
            cmd.Parameters.AddWithValue("@endDate", endDate);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    Appointment apt = new Appointment();
                    apt.title = myReader.GetString("title");
                    apt.startTime = myReader.GetDateTime("start").ToLocalTime();
                    apt.endTime = myReader.GetDateTime("end").ToLocalTime();
                    apt.contact = myReader.GetString("contact");
                    apt.customerName = myReader.GetString("customerName");
                    apt.description = myReader.GetString("description");
                    apt.location = myReader.GetString("location");
                    apt.aptType = myReader.GetString("type");
                    apt.url = myReader.GetString("url");
                    apt.user = myReader.GetString("userName");
                    results.Add(apt);
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public bool DoesCustomerExist(string customerName)
        {
            OpenConnection();
            string query = "select 1 from customer " +
                           "where customerName = @customerName";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerName", customerName);
            cmd.Connection = _connection;
            string result = Convert.ToString(cmd.ExecuteScalar());
            CloseConnection();
            return result == "1";
        }

        public void UpdateAppointment(string customerName, string userName, string title, string description,
            string location, string contact, string type, string url, DateTime start, DateTime end, string user, int appointmentId)
        {
            int customerId = GetCustomerId(customerName);
            int userId = GetUserId(userName);
            OpenConnection();
            string query =
                "update appointment " +
                "set customerId = @customerId, " +
                "userId = @userId, " +
                "title = @title, " +
                "description = @description, " +
                "location = @location, " +
                "contact = @contact, " +
                "type = @type, " +
                "url = @url, " +
                "start = @start, " +
                "end = @end, " +
                "lastUpdate = @lastUpdate, " +
                "lastUpdateBy = @lastUpdateBy " +
                "where appointmentId = @appointmentId";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@description", description);
            cmd.Parameters.AddWithValue("@location", location);
            cmd.Parameters.AddWithValue("@contact", contact);
            cmd.Parameters.AddWithValue("@type", type);
            cmd.Parameters.AddWithValue("@url", url);
            cmd.Parameters.AddWithValue("@start", DateTime.Parse(start.ToString("MM/dd/yyyy hh:mm:") + "00"));
            cmd.Parameters.AddWithValue("@end", DateTime.Parse(end.ToString("MM/dd/yyyy hh:mm:") + "59"));
            cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            cmd.Parameters.AddWithValue("@lastUpdateBy", user);
            cmd.Parameters.AddWithValue("@appointmentId", appointmentId);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();

        }

        public Appointment GetAppointmentToUpdate(DateTime startDate, DateTime endDate, string title)
        {
            Appointment results = new Appointment();
            OpenConnection();
            string query =
                " select appointmentId, contact, title, description, location, type, url, start, end, customerName, userName from appointment " +
                "join customer on customer.customerId = appointment.customerId " +
                "join user on user.userId = appointment.userId " +
                "where appointment.start = @startDate " +
                "and appointment.end = @endDate " +
                "and appointment.title = @title";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@startDate", startDate);
            cmd.Parameters.AddWithValue("@endDate", endDate);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    Appointment apt = new Appointment();
                    apt.title = myReader.GetString("title");
                    apt.startTime = myReader.GetDateTime("start");
                    apt.endTime = myReader.GetDateTime("end");
                    apt.contact = myReader.GetString("contact");
                    apt.customerName = myReader.GetString("customerName");
                    apt.description = myReader.GetString("description");
                    apt.location = myReader.GetString("location");
                    apt.aptType = myReader.GetString("type");
                    apt.url = myReader.GetString("url");
                    apt.user = myReader.GetString("userName");
                    apt.appointmentId = myReader.GetInt32("appointmentId");
                    results = apt;
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public void DeleteAppointment(DateTime start, DateTime end, string title)
        {
            OpenConnection();
            string query = "delete from appointment " +
                           "where start = @start " +
                           "and end = @end " +
                           "and title = @title";
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@start", start);
            cmd.Parameters.AddWithValue("@end", end);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public List<ReportItem> GetNumberOfAppointmentTypeByMonth(DateTime start, DateTime end)
        {
            List<ReportItem> results = new List<ReportItem>();
            OpenConnection();
            string query = "select count(*) as 'Count', type as 'Type' from appointment where start >= @start and end <= @end group by type";
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@start", start);
            cmd.Parameters.AddWithValue("@end", end);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    ReportItem repItem = new ReportItem();
                    repItem.num = myReader.GetInt32("Count");
                    repItem.type = myReader.GetString("Type");
                    results.Add(repItem);
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public List<Appointment> GetAppointmentsByUser(int userId)
        {
            List<Appointment> results = new List<Appointment>();
            OpenConnection();
            string query =
                " select contact, title, description, location, type, url, start, end, customerName, userName from appointment " +
                "join customer on customer.customerId = appointment.customerId " +
                "join user on user.userId = appointment.userId " +
                "where user.userId = @userId";
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    Appointment apt = new Appointment();
                    apt.title = myReader.GetString("title");
                    apt.startTime = myReader.GetDateTime("start").ToLocalTime();
                    apt.endTime = myReader.GetDateTime("end").ToLocalTime();
                    apt.contact = myReader.GetString("contact");
                    apt.customerName = myReader.GetString("customerName");
                    apt.description = myReader.GetString("description");
                    apt.location = myReader.GetString("location");
                    apt.aptType = myReader.GetString("type");
                    apt.url = myReader.GetString("url");
                    apt.user = myReader.GetString("userName");
                    results.Add(apt);
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public List<Appointment> GetAppointmentsByCustomer(int customerId)
        {
            List<Appointment> results = new List<Appointment>();
            OpenConnection();
            string query =
                " select contact, title, description, location, type, url, start, end, customerName, userName from appointment " +
                "join customer on customer.customerId = appointment.customerId " +
                "join user on user.userId = appointment.userId " +
                "where customer.customerId = @customerId";
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@customerId", customerId);
            cmd.Connection = _connection;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    Appointment apt = new Appointment();
                    apt.title = myReader.GetString("title");
                    apt.startTime = myReader.GetDateTime("start").ToLocalTime();
                    apt.endTime = myReader.GetDateTime("end").ToLocalTime();
                    apt.contact = myReader.GetString("contact");
                    apt.customerName = myReader.GetString("customerName");
                    apt.description = myReader.GetString("description");
                    apt.location = myReader.GetString("location");
                    apt.aptType = myReader.GetString("type");
                    apt.url = myReader.GetString("url");
                    apt.user = myReader.GetString("userName");
                    results.Add(apt);
                }
            }
            finally
            {
                myReader.Close();
            }

            CloseConnection();
            return results;
        }

        public void PopulateTestData()
        {
            OpenConnection();
            string query = @"
            INSERT INTO country VALUES
            (1, 'US', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (2, 'Canada', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (3, 'Norway', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test');
            INSERT INTO city VALUES
            (1, 'New York', 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (2, 'Los Angeles', 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (3, 'Toronto', 2, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (4, 'Vancouver', 2, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (5, 'Oslo', 3, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test');
            INSERT INTO address VALUES
            (1, '123 Main', '', 1, '11111', '555-1212', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (2, '123 Elm', '', 3, '11112', '555-1213', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (3, '123 Oak', '', 5, '11113', '555-1214', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test');
            INSERT INTO customer VALUES
            (1, 'John Doe', 1, 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (2, 'Alfred E Newman', 2, 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (3, 'Ina Prufung', 3, 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test');
            INSERT INTO user VALUES
            (1, 'test', 'test', 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test');
            INSERT INTO appointment VALUES
            (1, 1, 1, 'not needed', 'not needed', 'not needed', 'not needed', 'Presentation', 'not needed', '2019-01-01 00:00:00', '2019-01-01 00:00:00', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),
            (2, 2, 1, 'not needed', 'not needed', 'not needed', 'not needed', 'Scrum', 'not needed', '2019-01-01 00:00:00', '2019-01-01 00:00:00', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'); ";

            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = _connection;
            cmd.ExecuteNonQuery();
            CloseConnection();
        }
    }
}