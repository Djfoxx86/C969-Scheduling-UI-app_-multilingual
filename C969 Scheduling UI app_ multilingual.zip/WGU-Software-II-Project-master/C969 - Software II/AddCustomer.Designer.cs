﻿namespace SchedulingAssistant
{
    partial class AddCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customerNameText = new System.Windows.Forms.TextBox();
            this.customerName = new System.Windows.Forms.Label();
            this.addressText = new System.Windows.Forms.TextBox();
            this.cityText = new System.Windows.Forms.TextBox();
            this.postalCodeText = new System.Windows.Forms.TextBox();
            this.address2Text = new System.Windows.Forms.TextBox();
            this.countryText = new System.Windows.Forms.TextBox();
            this.country = new System.Windows.Forms.Label();
            this.postalCode = new System.Windows.Forms.Label();
            this.city = new System.Windows.Forms.Label();
            this.address2 = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.Label();
            this.phone = new System.Windows.Forms.Label();
            this.phoneText = new System.Windows.Forms.TextBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.activeCheckbox = new System.Windows.Forms.CheckBox();
            this.phoneFormat = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // customerNameText
            // 
            this.customerNameText.BackColor = System.Drawing.Color.Tomato;
            this.customerNameText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerNameText.Location = new System.Drawing.Point(24, 80);
            this.customerNameText.Name = "customerNameText";
            this.customerNameText.Size = new System.Drawing.Size(294, 26);
            this.customerNameText.TabIndex = 0;
            this.customerNameText.TextChanged += new System.EventHandler(this.CustomerNameText_TextChanged);
            // 
            // customerName
            // 
            this.customerName.AutoSize = true;
            this.customerName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerName.Location = new System.Drawing.Point(21, 59);
            this.customerName.Name = "customerName";
            this.customerName.Size = new System.Drawing.Size(126, 18);
            this.customerName.TabIndex = 7;
            this.customerName.Text = "Customer Name";
            // 
            // addressText
            // 
            this.addressText.BackColor = System.Drawing.Color.Tomato;
            this.addressText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressText.Location = new System.Drawing.Point(24, 194);
            this.addressText.Name = "addressText";
            this.addressText.Size = new System.Drawing.Size(294, 26);
            this.addressText.TabIndex = 8;
            this.addressText.TextChanged += new System.EventHandler(this.AddressText_TextChanged);
            // 
            // cityText
            // 
            this.cityText.BackColor = System.Drawing.Color.Tomato;
            this.cityText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityText.Location = new System.Drawing.Point(24, 315);
            this.cityText.Name = "cityText";
            this.cityText.Size = new System.Drawing.Size(134, 26);
            this.cityText.TabIndex = 9;
            this.cityText.TextChanged += new System.EventHandler(this.CityText_TextChanged);
            // 
            // postalCodeText
            // 
            this.postalCodeText.BackColor = System.Drawing.Color.Tomato;
            this.postalCodeText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postalCodeText.Location = new System.Drawing.Point(164, 315);
            this.postalCodeText.Name = "postalCodeText";
            this.postalCodeText.Size = new System.Drawing.Size(154, 26);
            this.postalCodeText.TabIndex = 10;
            this.postalCodeText.TextChanged += new System.EventHandler(this.PostalCodeText_TextChanged);
            // 
            // address2Text
            // 
            this.address2Text.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address2Text.Location = new System.Drawing.Point(24, 254);
            this.address2Text.Name = "address2Text";
            this.address2Text.Size = new System.Drawing.Size(294, 26);
            this.address2Text.TabIndex = 11;
            // 
            // countryText
            // 
            this.countryText.BackColor = System.Drawing.Color.Tomato;
            this.countryText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.countryText.Location = new System.Drawing.Point(24, 374);
            this.countryText.Name = "countryText";
            this.countryText.Size = new System.Drawing.Size(215, 26);
            this.countryText.TabIndex = 12;
            this.countryText.TextChanged += new System.EventHandler(this.CountryText_TextChanged);
            // 
            // country
            // 
            this.country.AutoSize = true;
            this.country.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.country.Location = new System.Drawing.Point(21, 353);
            this.country.Name = "country";
            this.country.Size = new System.Drawing.Size(67, 18);
            this.country.TabIndex = 13;
            this.country.Text = "Country";
            // 
            // postalCode
            // 
            this.postalCode.AutoSize = true;
            this.postalCode.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postalCode.Location = new System.Drawing.Point(164, 294);
            this.postalCode.Name = "postalCode";
            this.postalCode.Size = new System.Drawing.Size(96, 18);
            this.postalCode.TabIndex = 14;
            this.postalCode.Text = "Postal Code";
            // 
            // city
            // 
            this.city.AutoSize = true;
            this.city.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.city.Location = new System.Drawing.Point(21, 294);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(38, 18);
            this.city.TabIndex = 15;
            this.city.Text = "City";
            // 
            // address2
            // 
            this.address2.AutoSize = true;
            this.address2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address2.Location = new System.Drawing.Point(21, 233);
            this.address2.Name = "address2";
            this.address2.Size = new System.Drawing.Size(82, 18);
            this.address2.TabIndex = 16;
            this.address2.Text = "Address 2";
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.Location = new System.Drawing.Point(21, 173);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(68, 18);
            this.address.TabIndex = 17;
            this.address.Text = "Address";
            // 
            // phone
            // 
            this.phone.AutoSize = true;
            this.phone.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone.Location = new System.Drawing.Point(21, 117);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(54, 18);
            this.phone.TabIndex = 18;
            this.phone.Text = "Phone";
            // 
            // phoneText
            // 
            this.phoneText.BackColor = System.Drawing.Color.Tomato;
            this.phoneText.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneText.Location = new System.Drawing.Point(24, 138);
            this.phoneText.Name = "phoneText";
            this.phoneText.Size = new System.Drawing.Size(168, 26);
            this.phoneText.TabIndex = 19;
            this.phoneText.TextChanged += new System.EventHandler(this.PhoneText_TextChanged);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(189, 431);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(91, 49);
            this.cancelButton.TabIndex = 21;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(60, 431);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(91, 49);
            this.saveButton.TabIndex = 20;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // activeCheckbox
            // 
            this.activeCheckbox.AutoSize = true;
            this.activeCheckbox.Checked = true;
            this.activeCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.activeCheckbox.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activeCheckbox.Location = new System.Drawing.Point(23, 24);
            this.activeCheckbox.Name = "activeCheckbox";
            this.activeCheckbox.Size = new System.Drawing.Size(74, 22);
            this.activeCheckbox.TabIndex = 23;
            this.activeCheckbox.Text = "Active";
            this.activeCheckbox.UseVisualStyleBackColor = true;
            // 
            // phoneFormat
            // 
            this.phoneFormat.AutoSize = true;
            this.phoneFormat.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneFormat.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.phoneFormat.Location = new System.Drawing.Point(81, 121);
            this.phoneFormat.Name = "phoneFormat";
            this.phoneFormat.Size = new System.Drawing.Size(111, 13);
            this.phoneFormat.TabIndex = 24;
            this.phoneFormat.Text = "Format:  ###-####";
            // 
            // AddCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 521);
            this.Controls.Add(this.phoneFormat);
            this.Controls.Add(this.activeCheckbox);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.phoneText);
            this.Controls.Add(this.phone);
            this.Controls.Add(this.address);
            this.Controls.Add(this.address2);
            this.Controls.Add(this.city);
            this.Controls.Add(this.postalCode);
            this.Controls.Add(this.country);
            this.Controls.Add(this.countryText);
            this.Controls.Add(this.address2Text);
            this.Controls.Add(this.postalCodeText);
            this.Controls.Add(this.cityText);
            this.Controls.Add(this.addressText);
            this.Controls.Add(this.customerName);
            this.Controls.Add(this.customerNameText);
            this.Name = "AddCustomer";
            this.Text = "Add/Update Customer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox customerNameText;
        private System.Windows.Forms.Label customerName;
        private System.Windows.Forms.TextBox addressText;
        private System.Windows.Forms.TextBox cityText;
        private System.Windows.Forms.TextBox postalCodeText;
        private System.Windows.Forms.TextBox address2Text;
        private System.Windows.Forms.TextBox countryText;
        private System.Windows.Forms.Label country;
        private System.Windows.Forms.Label postalCode;
        private System.Windows.Forms.Label city;
        private System.Windows.Forms.Label address2;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.Label phone;
        private System.Windows.Forms.TextBox phoneText;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.CheckBox activeCheckbox;
        private System.Windows.Forms.Label phoneFormat;
    }
}