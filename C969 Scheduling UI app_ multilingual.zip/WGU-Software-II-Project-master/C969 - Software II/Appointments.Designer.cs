﻿namespace SchedulingAssistant
{
    partial class Appointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.customers = new System.Windows.Forms.Button();
            this.dgvAppointments = new System.Windows.Forms.DataGridView();
            this.addAppointment = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.cal = new System.Windows.Forms.MonthCalendar();
            this.radioDay = new System.Windows.Forms.RadioButton();
            this.radioWeek = new System.Windows.Forms.RadioButton();
            this.radioMonth = new System.Windows.Forms.RadioButton();
            this.radioPanel = new System.Windows.Forms.Panel();
            this.updateAppointment = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.delete = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppointments)).BeginInit();
            this.radioPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // customers
            // 
            this.customers.Location = new System.Drawing.Point(31, 448);
            this.customers.Name = "customers";
            this.customers.Size = new System.Drawing.Size(122, 49);
            this.customers.TabIndex = 4;
            this.customers.Text = "Customers";
            this.customers.UseVisualStyleBackColor = true;
            this.customers.Click += new System.EventHandler(this.addCustomer_Click);
            // 
            // dgvAppointments
            // 
            this.dgvAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAppointments.Location = new System.Drawing.Point(345, 52);
            this.dgvAppointments.Name = "dgvAppointments";
            this.dgvAppointments.Size = new System.Drawing.Size(831, 358);
            this.dgvAppointments.TabIndex = 5;
            // 
            // addAppointment
            // 
            this.addAppointment.Location = new System.Drawing.Point(570, 448);
            this.addAppointment.Name = "addAppointment";
            this.addAppointment.Size = new System.Drawing.Size(122, 49);
            this.addAppointment.TabIndex = 6;
            this.addAppointment.Text = "Add";
            this.addAppointment.UseVisualStyleBackColor = true;
            this.addAppointment.Click += new System.EventHandler(this.addAppointment_Click);
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(1012, 448);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(122, 49);
            this.exit.TabIndex = 7;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // cal
            // 
            this.cal.Location = new System.Drawing.Point(31, 230);
            this.cal.Name = "cal";
            this.cal.TabIndex = 8;
            this.cal.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.MonthCalendar1_DateChanged);
            // 
            // radioDay
            // 
            this.radioDay.AutoSize = true;
            this.radioDay.Checked = true;
            this.radioDay.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioDay.Location = new System.Drawing.Point(12, 34);
            this.radioDay.Name = "radioDay";
            this.radioDay.Size = new System.Drawing.Size(55, 22);
            this.radioDay.TabIndex = 9;
            this.radioDay.TabStop = true;
            this.radioDay.Text = "Day";
            this.radioDay.UseVisualStyleBackColor = true;
            this.radioDay.CheckedChanged += new System.EventHandler(this.radioDay_CheckedChanged);
            // 
            // radioWeek
            // 
            this.radioWeek.AutoSize = true;
            this.radioWeek.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioWeek.Location = new System.Drawing.Point(12, 75);
            this.radioWeek.Name = "radioWeek";
            this.radioWeek.Size = new System.Drawing.Size(68, 22);
            this.radioWeek.TabIndex = 11;
            this.radioWeek.Text = "Week";
            this.radioWeek.UseVisualStyleBackColor = true;
            this.radioWeek.CheckedChanged += new System.EventHandler(this.radioWeek_CheckedChanged);
            // 
            // radioMonth
            // 
            this.radioMonth.AutoSize = true;
            this.radioMonth.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioMonth.Location = new System.Drawing.Point(12, 114);
            this.radioMonth.Name = "radioMonth";
            this.radioMonth.Size = new System.Drawing.Size(72, 22);
            this.radioMonth.TabIndex = 10;
            this.radioMonth.Text = "Month";
            this.radioMonth.UseVisualStyleBackColor = true;
            this.radioMonth.CheckedChanged += new System.EventHandler(this.radioMonth_CheckedChanged);
            // 
            // radioPanel
            // 
            this.radioPanel.Controls.Add(this.radioDay);
            this.radioPanel.Controls.Add(this.radioMonth);
            this.radioPanel.Controls.Add(this.radioWeek);
            this.radioPanel.Location = new System.Drawing.Point(31, 52);
            this.radioPanel.Name = "radioPanel";
            this.radioPanel.Size = new System.Drawing.Size(227, 166);
            this.radioPanel.TabIndex = 12;
            // 
            // updateAppointment
            // 
            this.updateAppointment.Location = new System.Drawing.Point(719, 448);
            this.updateAppointment.Name = "updateAppointment";
            this.updateAppointment.Size = new System.Drawing.Size(122, 49);
            this.updateAppointment.TabIndex = 13;
            this.updateAppointment.Text = "Update";
            this.updateAppointment.UseVisualStyleBackColor = true;
            this.updateAppointment.Click += new System.EventHandler(this.updateAppointment_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 60000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(866, 448);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(122, 49);
            this.delete.TabIndex = 14;
            this.delete.Text = "Delete";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(371, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(174, 28);
            this.button1.TabIndex = 15;
            this.button1.Text = "# of Apt. Type by Month Report";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(570, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(192, 28);
            this.button2.TabIndex = 16;
            this.button2.Text = "Schedule per Consultant";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(780, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(192, 28);
            this.button4.TabIndex = 18;
            this.button4.Text = "Schedule per Customer";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Appointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1188, 530);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.updateAppointment);
            this.Controls.Add(this.radioPanel);
            this.Controls.Add(this.cal);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.addAppointment);
            this.Controls.Add(this.dgvAppointments);
            this.Controls.Add(this.customers);
            this.Name = "Appointments";
            this.Text = "Appointments";
            this.Load += new System.EventHandler(this.Appointments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppointments)).EndInit();
            this.radioPanel.ResumeLayout(false);
            this.radioPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button customers;
        private System.Windows.Forms.DataGridView dgvAppointments;
        private System.Windows.Forms.Button addAppointment;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.MonthCalendar cal;
        private System.Windows.Forms.RadioButton radioDay;
        private System.Windows.Forms.RadioButton radioWeek;
        private System.Windows.Forms.RadioButton radioMonth;
        private System.Windows.Forms.Panel radioPanel;
        private System.Windows.Forms.Button updateAppointment;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
    }
}