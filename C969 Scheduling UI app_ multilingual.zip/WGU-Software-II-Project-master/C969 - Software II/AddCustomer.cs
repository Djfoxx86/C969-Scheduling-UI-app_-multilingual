﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace SchedulingAssistant
{
    public partial class AddCustomer : Form
    {
        DbRepository repo = new DbRepository();
        private Customers customers;
        private bool update = false;
        private int _customerId;
        private Languages _languages;
        public AddCustomer(Customers customersMain, Languages language)
        {
            _languages = language;
            customers = customersMain;
            InitializeComponent();
            SetLanguage();
            QualityCheck();
        }

        public AddCustomer(Customers customersMain, string customerName, string address, string address2,
            string postalCode, string phone, string city, string country, string active, int customerId, Languages language)
        {
            _languages = language;
            customers = customersMain;
            InitializeComponent();
            customerNameText.Text = customerName;
            addressText.Text = address;
            address2Text.Text = address2;
            postalCodeText.Text = postalCode;
            phoneText.Text = phone;
            cityText.Text = city;
            countryText.Text = country;
            activeCheckbox.Checked = active == "1" ? true : false;
            update = true;
            _customerId = customerId;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (update)
            {
                Dictionary<string, int> customerData = repo.GetCustomerDataIdsToUpdate(_customerId);
                repo.UpdateCustomer(_customerId, customerData["addressId"], customerData["cityId"],
                    customerData["countryId"], customerNameText.Text, addressText.Text, address2Text.Text,
                    postalCodeText.Text, phoneText.Text, cityText.Text, countryText.Text, activeCheckbox.Checked,
                    customers.appointments.landing.currentUser);
                customers.Refresh();
                this.Close();
            }
            else
            {
                try
                {
                    bool exists = repo.DoesCustomerExist(customerNameText.Text);
                    if (exists)
                    {
                        throw new CustomerAlreadyExists(String.Format("{0} {1}", customerNameText.Text,
                            _languages.customerAlreadyExists));
                    }
                    repo.AddCustomer(customerNameText.Text, addressText.Text, address2Text.Text, postalCodeText.Text,
                        phoneText.Text, cityText.Text, countryText.Text, activeCheckbox.Checked, customers.appointments.landing.currentUser);
                    customers.Refresh();
                    this.Close();
                }
                catch (CustomerAlreadyExists ex)
                {
                    ExceptionMessage exception = new ExceptionMessage(ex.Message, _languages);
                    exception.Show();
                }
            }
        }

        private void SetLanguage()
        {
            activeCheckbox.Text = _languages.active;
            customerName.Text = _languages.customerName;
            phone.Text = _languages.phone;
            address.Text = _languages.address;
            address2.Text = _languages.address + " 2";
            city.Text = _languages.city;
            postalCode.Text = _languages.postalCode;
            country.Text = _languages.country;
            saveButton.Text = _languages.save;
            cancelButton.Text = _languages.cancel;
            this.Text = _languages.addUpdateCustomers;
        }

        private void QualityCheck()
        {
            if(customerNameText.BackColor == System.Drawing.Color.Yellow ||
                phoneText.BackColor == System.Drawing.Color.Yellow || 
                addressText.BackColor == System.Drawing.Color.Yellow ||
                cityText.BackColor == System.Drawing.Color.Yellow ||
                postalCodeText.BackColor == System.Drawing.Color.Yellow ||
                countryText.BackColor == System.Drawing.Color.Yellow)
            {
                saveButton.Enabled = false;
            }
            else
            {
                saveButton.Enabled = true;
            }
        }

        private void CustomerNameText_TextChanged(object sender, EventArgs e)
        {
            customerNameText.BackColor = customerNameText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void AddressText_TextChanged(object sender, EventArgs e)
        {
            addressText.BackColor = addressText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void CityText_TextChanged(object sender, EventArgs e)
        {
            cityText.BackColor = Regex.IsMatch(cityText.Text, @"^[a-zA-Z ]+$") && cityText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void PostalCodeText_TextChanged(object sender, EventArgs e)
        {
            postalCodeText.BackColor = Regex.IsMatch(postalCodeText.Text, @"^[0-9]+$") && postalCodeText.Text.Length == 5 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void CountryText_TextChanged(object sender, EventArgs e)
        {
            countryText.BackColor = countryText.Text.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
            QualityCheck();
        }

        private void PhoneText_TextChanged(object sender, EventArgs e)
        {
            phoneText.BackColor = Regex.IsMatch(phoneText.Text, @"^[\d\d\d-\d\d\d\d]+$") && phoneText.Text.Length == 8 ? System.Drawing.Color.White : System.Drawing.Color.Yellow;
        }
    }

    [Serializable]
    public class CustomerAlreadyExists : Exception
    {
        public CustomerAlreadyExists()
        {

        }

        public CustomerAlreadyExists(string message)
            : base(message)
        {

        }
    }
}
